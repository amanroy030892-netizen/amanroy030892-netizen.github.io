# Code

The implemented SafarSaarthi app and supporting code belong here. Build configuration can stay at the repository root when required by the tooling.
