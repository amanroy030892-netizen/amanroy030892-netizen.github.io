# Phase 4 — Realtime Database model

RTDB holds only current connection and active location. Booking, duty, entitlement and review state remain in [Firestore](FIRESTORE_DATA_MODEL.md). No GPS history collection is approved. E10 in the [entity catalog](DATA_ENTITY_CATALOG.md) is ephemeral.

```text
/presence/{driverUid}/{connectionId} = {connected:bool, lastSeenAt:serverTimestamp}
/activeDriverLocations/{driverUid} = {lat:number, lng:number, geohash:string, recordedAt:serverTimestamp, shiftId:string, vehicleId:string, sequence:int}
/publicDriverCells/{cellKey}/{driverUid} = {approxLat:number, approxLng:number, type:"eRickshaw", freshnessAt:serverTimestamp}
/privateTripLocations/{tripType}/{tripId}/{driverUid} = {lat:number, lng:number, recordedAt:serverTimestamp, sequence:int}
/trackingGrants/{tripType}/{tripId}/{passengerUid} = {allowed:bool, expiresAt:serverTimestamp}
```

`publicDriverCells` is a short-lived server projection of eligible on-duty e-rickshaw drivers, spatially rounded to avoid exposing precise pre-booking coordinates (D12). The exact geohash precision and update interval are load-tested against UQ08/UQ09, not hardcoded as product rules. A mobile client supplies signed-in own-driver coordinates only with active foreground location permission; server checks current shift, assigned vehicle, pass/document/restriction and recorded timestamp before publishing a public cell. The public marker is hidden when break/off duty, ineligible, busy, or more than **60 seconds** stale (R09/D12). A stale projection is never treated as booking eligibility; `createRideRequest` rechecks Firestore in a transaction.

On connection, each device creates its own `/presence/{uid}/{connectionId}` entry and registers `onDisconnect` to mark/remove it. A server summary treats a driver offline when no live connections remain. `onDisconnect` is best effort; a scheduled sweeper removes stale location and cell entries, and readers also enforce freshness. Client clock is not trusted. Use server timestamps plus monotonic sequence to reject old updates. A lost GPS fix keeps the active booking intact, displays the last update privately, and removes the public marker after freshness failure. Break removes public presence but may retain private carpool sharing after explicit “On the way” (D21/G04).

Nearby lookup: `findNearbyDrivers` queries bounded geohash ranges in `/activeDriverLocations`, computes exact straight-line distance and current eligibility on the server at 3 km, and permits 5 km **only when 3 km is empty** (D07). RTDB indexes `geohash` on active locations; multiple bounds are merged and deduplicated. The callable returns approximate markers, never raw coordinates. `/publicDriverCells` can feed bounded map subscriptions as a coarse projection; it does not decide exact radius or booking eligibility. If measured cell fan-out is unnecessary, omit that optional projection and use bounded callable refreshes. Do not create permanent per-fix records.

Rules plan: default deny. A driver may write only their own current connection/location path with Auth UID, validated numeric lat/lng, sequence and allowable shape; no client writes to public cells or grants. A passenger may read only bounded public cells. Precise `/privateTripLocations` reads require current confirmed booking membership and sharing state; because RTDB rules cannot safely join arbitrary Firestore records, a short-lived server-owned `/trackingGrants` entry is created/revoked with booking/sharing transitions and checked by rules. Admin has no blanket live-location browsing. App Check complements Auth/rules. A server worker enforces eligibility and removes grants/locations at completion/cancellation; rule tests must exercise cross-driver writes, stale grants and revoked accounts.

Traffic model: active driver writes at a configurable movement/time threshold, slows when stationary, pauses public updates on break, and sends private trip updates only while assigned/on-the-way. Bound `connections × subscribed_cells × update_rate` and bytes per snapshot; avoid a listener on the entire driver tree. See [cost review](FIREBASE_COST_AND_PERFORMANCE.md).
