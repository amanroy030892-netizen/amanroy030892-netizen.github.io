# Phase 3 — lifecycle state machines

**Scope:** conceptual lifecycle contracts for M01–M14, based on [requirements](REQUIREMENTS_INDEX.md), [decisions](DECISION_REGISTER.md), and the [Q&A](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Questions-and-Answers.md). State names below organize confirmed behavior; they are **not** database enums or client-approved new rules. Every server-controlled transition must be checked against current actor, record, deadline and version. Retry of an uncertain action resolves its original result (R23/D26). Screen IDs point to [SCREEN_TRANSITIONS.md](SCREEN_TRANSITIONS.md).

## 1. Authentication and role access — M01

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Signed out → OTP challenge → phone verified | Passenger/driver account; S01→S02 | Valid phone challenge/code; language may be changed pre-OTP | Invalid/expired code remains S02; offline cannot verify | R01,R22; D02–D03; Q01,Q57 |
| Phone verified → named passenger | Account holder; S03 save | Name supplied and persisted | S03 validation/save error; booking gated | R01; D03; Q01 |
| Named passenger → driver applicant mode | Account holder; P01→S05→D02 | Same account; no second driver profile | Existing application routes D05, not duplicate | R01–R02; D03–D04; Q01–02 |
| Passenger ↔ approved driver mode | Account holder; S05 | Driver access uses current approval; on-duty idle switching to passenger requires break | Underway driver ride remains D13; stale mode cannot bypass gates | R01,R10; D03,D13; Q55–56 |
| Staff signed out → authorized admin | Staff; A01 | Individual authorized role | Unauthorized/expired stays A01; no protected A02–A12 | R20; D23; Q46 |

## 2. Driver person/vehicle approval — M02,M13

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| No application → draft → submitted/pending | Applicant; D02–D04 | Profile photo, licence sides, Aadhaar evidence; each vehicle RC and owner authorization when mismatched | Missing evidence stays draft; UQ04 decides masked/selfie detail | R02; D04–D05; Q02–04; UQ04 |
| Pending → needs correction → resubmitted/pending | Staff A03/A04 then applicant D05→D03/D04 | Specific document and reviewer reason | Unchanged other approved vehicles remain available if licence valid | R02–R03; D06; Q05–06 |
| Pending → approved person and/or approved driver-vehicle relation | Staff A03/A04 | Manual review; capacity and expiry recorded for vehicle | Incomplete review cannot grant duty or publication | R02–R04; D04–D06,D25; Q02–06,Q78–79 |
| Approved → renewal pending → approved with new expiry | Driver D06 then staff A03/A04 | Early upload; old approval remains valid until old expiry | If old expiry passes before decision, new work blocked at person/vehicle scope | R03; D25; Q80–81 |
| Approved → expired/suspended new-work block | Time or staff A09 | Licence expiry blocks driver; RC expiry/vehicle suspension blocks vehicle; driver suspension blocks all | Underway ride finishes; active/upcoming bookings go A10 review, not auto-cancel | R03,R21; D24–D25; Q48,Q80 |

**Unspecified branch:** D05 inventory includes a rejected status, but the source defines correction, approval and suspension, not a final rejection/appeal/reapplication policy. Treat rejection as a restricted display state until that policy is confirmed; do not create a write transition from it. UQ04/UQ16 and [coverage report](JOURNEY_COVERAGE_REPORT.md).

## 3. Driver duty and shift — M04

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Off duty/break → On Duty available | Driver D10 | Approved person and selected e-rickshaw, valid licence/RC, pass eligibility, fresh GPS, no shared registration duty conflict, no carpool pause | D10 shows exact blocker; no public marker until fresh location | R04,R09–R10,R16,R24; D12–D13,D19–D20,D25,D27; Q22–23,Q74–79 |
| On Duty available → busy/assigned | System on D11 accept; D12/D13 | Current request within 45 seconds; no other active driver assignment | Decline/expiry releases to available only if still eligible/on duty | R06,R10; D08,D13; Q09,Q31,Q76 |
| On Duty available → break/off duty | Driver D10 or S05 | No unresolved request/underway ride for vehicle change or passenger switch | Underway ride remains D13; public marker removed on break | R09–R10; D12–D13; Q29,Q56,Q74 |
| On Duty available → carpool pause | Clock/system at T−30 before a booked carpool | At least one seat booked | New requests stop; underway e-rickshaw ride finishes; off-duty carpool still listed | R16; D19; Q22–23 |
| On Duty/busy → shift ended or eligibility blocked | Clock/system at 12 hours, pass/doc expiry or suspension | New on-demand work stops | Assigned underway ride finishes; no automatic public return | R03,R10,R21,R24; D13,D24–D25,D27; Q75–76,Q80; UQ03 |
| Completed ride → available or break | System after D15 sync; driver may choose Finish and take a break | Current eligibility, On Duty, fresh GPS, no T−30 pause | Otherwise D01 blocked/break; pending sync retains nonpublic state | R10,R23; D13,D19,D26; Q76 |

## 4. Shared driver pass — M11,M04

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Free eligible → free active pass | Eligible driver D07/system | Admin mode Free, approval gates | Show expiry; no checkout | R24; D27; Q82–84 |
| Paid no pass → purchase pending → verified active | Driver D08, Razorpay return D09, server verification | Admin mode Paid, configured package and applicable Play checkout route | Pending/failed grants no pass; retry verifies original attempt; successful repeated notice grants once | R24; D27; Q82,Q86; UQ05,UQ15 |
| Active pass → expired | Continuous clock | Issue/purchase start per package rule | Break/offline does not pause; underway work treatment follows confirmed ride rule and open UQ01/UQ03 for carpool | R10,R24; D13,D27; Q75,Q83–85; UQ01,UQ03,UQ05 |
| Free ↔ Paid mode | Authorized admin A12 | Audit staff/time; existing-pass rule must be decided | Do not implement silent revoke/extension; retain explicit conditional states | R24; D27; Q82,Q99; UQ02 |

**Unapproved branches:** UQ01 asks publication vs departure vs another carpool checkpoint; UQ02 asks existing-pass treatment; UQ03 relates shift/pass clocks; UQ05 fixes catalogue/start; UQ06 fixes release placement; UQ15 fixes checkout route. The example ₹100/12 hours is not a final package. Razorpay remains the recorded gateway choice, not proof that a Play-distributed paid route is approved. D27; Q82–86,Q99.

## 5. E-rickshaw request and fare booking — M05,M06

```mermaid
stateDiagram-v2
  [*] --> Selected
  Selected --> PendingRequest: passenger sends to one driver
  PendingRequest --> Declined: driver declines
  PendingRequest --> Expired: 45 s deadline
  PendingRequest --> Negotiating: driver accepts
  Negotiating --> OfferVisible: driver submits/revises version
  OfferVisible --> Negotiating: revised version replaces old
  OfferVisible --> Booked: passenger accepts current version
  Negotiating --> Expired: fare window ends under call rule
  OfferVisible --> Expired: fare window ends under call rule
  PendingRequest --> Cancelled: pre-pickup cancellation
  Negotiating --> Cancelled: pre-pickup cancellation
  Booked --> RideFulfillment: assigned booking
```

| Transition | Actor / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Selected → PendingRequest | Passenger P04 | Pickup/destination and selected eligible driver; passenger has no other active request/ride | Busy/active conflict stays P04; uncertain write resolves original action | R05–R06; D07–D08; Q07–09,Q70 |
| PendingRequest → Negotiating/Declined/Expired | Driver D11 or clock | Selected driver responds by 45 seconds | Late accept rejected; P05 selects another driver | R06,R18; D08; Q09,Q31–32 |
| Negotiating → OfferVisible/revised | Driver D12; S06 may stay active | Amount/version; five-minute timer, or active call extension | Stale offer cannot be accepted; call ending gives 60 seconds to outstanding offer | R06–R07; D09–D10; Q10,Q31,Q35 |
| OfferVisible → Booked | Passenger P06/S06 | Accept exact visible current version within valid window | Lost response → S08 original-action check; stale version shows latest P06 | R06–R07,R23; D09–D10,D26; Q10,Q31,Q66 |
| Any pre-pickup active state → Cancelled | Either participant with reason | Server confirms before PIN pickup | No fee; release only after authoritative result | R08; D11; Q37 |

## 6. E-rickshaw ride fulfillment — M07

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Booked → en route → arrived/waiting | Driver D13 | Assigned booking; mark arrival | GPS/network loss pauses tracking but preserves ride; P07 shows last update | R08–R09; D11–D12; Q11,Q28–30,Q38 |
| Arrived/waiting → no-show | Driver D13 after arrival + 5 minutes | Explicit action, not timer alone | Too early rejected; booking remains open | R08; D11; Q38 |
| Arrived/waiting → underway | Driver D14 online PIN verification | Four-digit PIN for assigned ride | Wrong/offline stays booked and allows retry; no start without server | R08,R23; D11,D26; Q11,Q67 |
| Underway → completed | Driver D15 | Assigned ride; completion action | Offline action Pending sync, conflict reviewed; never silently rewrites admin event | R08,R17,R23; D18,D26; Q41,Q68 |
| Completed → payment outstanding/received | Driver D15; direct fare | Agreed amount; separate receipt action | Offline receipt Pending sync; trip stays completed | R17,R23; D18,D28,D26; Q41,Q68 |

## 7. Carpool listing and seat booking — M08,M09,M10

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Published: eligible driver publishes
  Published --> BookedListing: first atomic seat booking
  BookedListing --> Full: all seats reserved
  Full --> BookedListing: seats freed before cutoff
  Published --> Cancelled: driver cancels
  BookedListing --> Cancelled: driver cancels all bookings
  Full --> Cancelled: driver cancels all bookings
  BookedListing --> Departed: scheduled departure/operation
  Full --> Departed: scheduled departure/operation
  Departed --> Completed: trip completion
```

| Transition | Actor / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Draft → Published | Driver D17 | Approved person/vehicle; enabled towns; dated one-way trip; seats ≤ capacity; no account/driver/vehicle schedule overlap; pass checkpoint UQ01 | Conflict/eligibility stays D17; no partial listing | R04,R11,R13,R24; D14,D20,D25,D27,D29; Q14–15,Q24,Q73,Q77–79,Q85 |
| Published → BookedListing/Full | Passenger P11/P12 | Booked passenger travels; not own trip or overlapping; all requested seats available; pass/listing gate per UQ01 | Atomic race loser sees current seats; original uncertain action checked once | R12–R13,R23; D15,D20,D26; Q17,Q66,Q71–73 |
| Confirmed booking → seat count changed | Passenger P14 | Online server receipt before T−15; increase fits all extra seats | Same booking ID/PIN; failure leaves original seats; decrease releases seats once | R12,R15,R23; D16,D26; Q69,Q72 |
| Confirmed booking → cancelled | Passenger P14 or driver D22 | Passenger online before T−15; driver cancellation affects all bookings | Server confirms release/notice once; offline request retains seats | R15,R23; D16–D17,D26; Q20,Q69 |
| Booked listing → on the way/late ETA | Driver D18/D21 | Booked fields fixed; private tracking starts by explicit action | Fare/route/pickup/departure change requires cancel/republish | R15–R16; D17,D21; Q26,Q40 |
| Confirmed booking → boarded/partial/no-show | Driver D20 | At/after departure; online PIN verifies booking; 0..booked headcount | Wrong/offline PIN stays unboarded; due = actual boarded × booked price | R14,R17,R23; D18,D26; Q21,Q25,Q39,Q67 |
| Departed → completed | Driver D21 | Trip operation completed | Completion and receipt can queue separately offline; sharing ends | R14,R16–R17,R23; D18,D21,D26; Q26,Q41,Q68 |

**Interpretation limit:** “Closed” is listed in Q22 as a searchability stop, but the handoff does not define a separate close action or timing. The diagram does not invent one. Exact handling of pass expiry after publication remains UQ01.

## 8. Payments — M11 with M07/M10

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| Ride/group fare due → outstanding | Booking confirmation or actual boarding; P07/P13,D15/D21 | E-rickshaw agreed fare or actual carpool boarded count × booked seat price | Booking/ride status does not depend on collection | R17; D18,D28; Q18,Q39,Q41 |
| Outstanding → receipt acknowledged | Driver D15/D21 | Direct cash/UPI paid to driver; separate idempotent receipt action | Offline Pending sync; conflict flagged; completion remains independent | R17,R23; D18,D26,D28; Q41,Q68 |
| Paid pass attempted → pending/failed/verified | Driver D08/D09, server | Razorpay attempt; success verified server-side | Pending/failed no entitlement; duplicate success one grant | R24; D27; Q86; UQ15 |

No in-app passenger ride-fare checkout is specified. Exact e-rickshaw collection moment is not specified; carpool fare is paid at pickup. Dispute/refund policy is UQ07. R17,D28,Q18,Q41,Q97.

## 9. Booking-linked support tickets — M12,M13

| From → to | Actor / trigger / screen | Preconditions | Failure or retry | Trace |
| --- | --- | --- | --- | --- |
| No issue → Open | Passenger/driver S10 | Owned booking ID; category and optional note | Offline/error remains draft; uncertain submission must be checked before another attempt | R20,R23; D22,D26; Q45,Q66; UQ07 |
| Open → In review | Authorized staff A06 | Individual staff identity and recorded status/action | Conflict reloads current issue; reporter S11 sees change | R20; D23; Q45–46 |
| Open/In review → Resolved | Authorized staff A06 | Resolution note and audit identity/time/reason | Failed write leaves prior status; original booking events unchanged | R20; D22–D23; Q45,Q49; UQ07 |

The baseline names Open, In review and Resolved; it does not define reopen/escalation/refund adjudication. Do not add those transitions without a decision. UQ07.
