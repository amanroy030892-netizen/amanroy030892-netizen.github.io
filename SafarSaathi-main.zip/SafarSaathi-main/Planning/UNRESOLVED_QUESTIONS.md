# SafarSaathi unresolved questions and gaps

**Review date:** 12 November 2026. These are decisions or inputs that the handoff explicitly leaves open, plus a few internal ambiguities identified across its plans. They do not override any [recorded decision](DECISION_REGISTER.md). Q numbers refer to the [100-question record](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Questions-and-Answers.md). The [client confirmation form](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Client-Confirmation.docx) has blank response and sign-off fields, so its proposed answers are not client-approved.

## Product decisions to resolve before detailed flow and data design

| ID | Question or gap | Why it matters | Source / present status |
| --- | --- | --- | --- |
| UQ01 | At what point must the shared driver pass be valid for a scheduled carpool: publication, departure, or another defined action? What happens to existing listings and seat bookings after expiry? | Controls listing eligibility, reservation and departure checks. | Q85 was open in the handoff; **resolved for planning by user confirmation as D33** in Phase 3 review. |
| UQ02 | When admin changes Free ↔ Paid mode, what happens to passes already issued? | Avoids silently removing or extending promised access. | Q99 was open in the handoff; **resolved for planning by user confirmation as D34** in Phase 3 review. |
| UQ03 | How do the 12-hour on-demand shift and continuous 12-hour shared pass interact, especially after a free-mode shift restarts, a pass expires mid-carpool, or paid mode is enabled? | The plan uses separate “shift” and “pass” clocks but does not define each transition. | Q75 and Q82–85 established both rules; **resolved for planning by user confirmation as D35** in Phase 3 review. |
| UQ04 | Is masked Aadhaar required, is a live selfie needed in addition to a profile photo, and what evidence is sufficient for manual review? | Changes onboarding, storage, review and privacy controls. | Q03/Q91 were open; **product choice recorded as D36**: masked Aadhaar, no separate selfie, with legal/privacy review still required before live collection. QR/OTP Aadhaar verification was **not requested**. |
| UQ05 | What is the final driver-pass catalogue, price, duration and entitlement start point? | ₹100/12 hours is only an example; paid purchase and expiry need actual packages. | **Resolved for planning by D37/D39**: one admin-editable price/duration; validity starts at server grant after verified purchase. Actual configured values are operational input, not fixed in this document. |
| UQ06 | Does the first pilot release need an operational, tested paid-pass checkout while configured Free, or is paid mode a later activation/release? | Project acceptance includes free → paid → free, but launch is Free and timing is not stated. | **Resolved for planning by D40**: first release includes tested paid path; production Paid activation waits for D41 checkout-route approval. |
| UQ07 | Which issue categories and resolution rules apply to unpaid rides, carpool no-shows, late cancellations, and direct-payment disputes? Is any refund adjudication needed? | Admin issue workflow is confirmed, but outcome policy is not. | **Resolved for pilot planning by D48–D49**: five categories and status/note-only admin resolution; no in-app money movement, refund or edits to original trip events. Direct fares remain cash/UPI. |

## Inputs needed before pilot operation or launch

| ID | Required input | Source / current answer |
| --- | --- | --- |
| UQ08 | Initial service towns/stands and which of the two services each town enables. | Q51 and Q89: admin controls towns, but no initial list. |
| UQ09 | Target Android devices/versions, pilot driver/passenger numbers, OTP volume, driver-hours and expected call/location load. | Q89–90: not provided; needed for test coverage and running-cost estimates. |
| UQ10 | Identity-document and precise-location retention/deletion periods, policy text, and data owner/reviewer responsibility. | **Controlled planning assumption and responsibility model recorded as D38**. Client/business owner approves final periods; client-appointed legal/privacy professional reviews before live collection. Exact periods and policy text remain a pre-launch dependency. |
| UQ11 | Support contact and policy author/reviewer, plus account-deletion and privacy/support page content. | **Navigation, owner/reviewer and active-obligation deletion approach resolved for planning by D43/D52.** Client/business owner must still supply the actual support contact and legally reviewed page content before publication. Final erasure timing follows D38. |
| UQ12 | Firebase, Maps billing, Agora and Play Console account owners; spending limits; production provisioning. | Q62–64, Q90. New client-owned Firebase production project is the plan; other ownership/details and setup remain pending. |
| UQ13 | Final icon/brand assets and required fidelity to the old HTML prototype. Can the original HTML ZIP be provided for reference? | Q88; the ZIP is not in this repository. Existing pilot-plan observations are from a static review, not verified live behavior. |
| UQ14 | Delivery start/date, scope fallback priority if schedule constrains the broad pilot, UAT owner, acceptance sign-off, APK/AAB/Play submission, signing ownership, post-handover support. | Q87, Q100. Native Android and new Play listing are already decided. |
| UQ15 | Applicable Play checkout route for paid driver discovery in the distributed build. | **Responsibility and activation gate agreed in D41; route determination remains open.** Client/business owner approves it in writing before Paid activation. Development team researches options; Razorpay remains preferred only where the approved route permits it. |
| UQ16 | Actual first release content and runbook for town setup, staff accounts, support and affected-booking review after suspension/expiry. | **Partially answered by D51/D53**: staff-only audited phone contact for affected bookings and client-controlled staff provisioning. Initial towns, actual staff accounts/support contact and operating runbook remain pending. |

## Documentation inconsistencies or interpretation risks

| ID | Finding | Safe reading for this review |
| --- | --- | --- |
| G01 | Repository title/GitHub spelling is **SafarSaarthi**, while public product name is **SafarSaathi**. | Q50 explicitly fixes the public name and package ID. Repository naming is an organizational mismatch, not authority to rename the product. |
| G02 | The detailed pilot plan calls its journeys “confirmed,” while the editable client confirmation document has no responses or sign-off. | Treat them as accepted internal planning baseline pending client validation. Do not mark client-approved. |
| G03 | Prototype referred to fee submission/UTR approval for visibility and `com.safarsaathi.app`. Later plans choose admin-controlled Free/Paid passes, Razorpay and `com.safarsaathi.rides`. | Later Q&A/project-plan corrections supersede prototype behavior. Do not revive the old fee or package ID. |
| G04 | “Break stops location sharing” appears in the on-demand summary, while carpool tracking may continue after On the way to pickup, including during break. | Read “break” as removing public e-rickshaw presence; private booked-carpool sharing follows Q26/Q29. Clarify wording in eventual detailed states without changing the rule. |
| G05 | The five-milestone project plan includes a large set of capabilities, while the term MVP has no separately approved subset. | Treat the documented pilot as the planned first delivery, not as evidence that every item has a committed date. UQ06 and UQ14 define the boundary questions. |
| G06 | Earlier prototype is described as a design reference, but the actual HTML ZIP and working app are absent from the reviewed repository. | Existing functionality cannot be independently validated here. No implementation or test completion is claimed. |

## Already answered; do not reopen without new evidence

Driver choice is manual (Q08, Q92); request search is 3 km then optional 5 km (Q27); Agora is the selected private voice method (Q09, Q33, Q93); fare is driver-proposed and passenger-accepted (Q10, Q94); booking PIN is required (Q11, Q21); carpool seats confirm instantly and fare is paid directly (Q17–18, Q96–97); the cancellation cutoff is 15 minutes (Q20, Q69); external maps provide navigation (Q60–61); Android languages and public name are set (Q50, Q53); prototype data migration is outside the plan (Q62); and the download remains free in both pass modes (Q82, Q99).

## Phase 2 classification and affected modules

These labels add design priority only; they do **not** answer the questions or change their source/status above. **BLOCKER** means the named workflow cannot be finalized without a decision. **DESIGN-DEPENDENT** means an explicitly labeled assumption can support draft work but needs confirmation before approval. **LATER** belongs to implementation, testing, deployment, or handover planning. Exact affected screen IDs are in the [wireframe execution plan](WIREFRAME_EXECUTION_PLAN.md#question-to-screen-impact-map).

**Phase 3 update:** UQ01–UQ03, UQ05–UQ07 are resolved for planning by D33–D35, D39–D40 and D48–D49. UQ04 has a product choice pending legal/privacy review (D36). UQ10 has an agreed responsibility model and controlled assumption, with final policy approval pending (D38). UQ11 has navigation, ownership and deletion-request handling decisions while actual content remains due (D43/D52). UQ15 has an agreed owner and activation gate while the checkout-route determination remains open (D41). UQ16 is partially answered by D51/D53. The classifications below are retained as historical priority labels, not current open status.

## Current status after the Phase 3 decision review

This table is the current status; the questions and Phase 2 priority classes above remain as historical source and triage context. “Controlled assumption” permits planning only, not production collection or paid activation.

| ID | Current status | Decision / remaining gate |
| --- | --- | --- |
| UQ01 | Resolved for planning | D33: pass checked at carpool publication; existing listings stay bookable and depart after pass expiry. |
| UQ02 | Resolved for planning | D34: already-issued passes remain valid to recorded expiry after mode change. |
| UQ03 | Resolved for planning | D35: independent shift/pass clocks, both required for new on-demand work. |
| UQ04 | Product choice confirmed; external review pending | D36: masked Aadhaar, no live selfie. Client-appointed legal/privacy reviewer must confirm collection/review approach before live evidence. |
| UQ05 | Resolved for planning | D37/D39: one admin-editable paid package; validity begins at server grant after verified purchase. Actual price/duration are admin configuration inputs. |
| UQ06 | Resolved for planning | D40: test paid path in first release, launch Free; production Paid activation gated. |
| UQ07 | Resolved for pilot planning | D48/D49: five issue categories and note-only admin resolution, no in-app money movement. |
| UQ08 | Open, nonblocking for architecture | Initial town/stand values and service flags needed before pilot operation. |
| UQ09 | Open, later validation input | Target devices, usage/load figures needed for test and capacity plan. |
| UQ10 | Controlled planning assumption; pre-launch policy gate | D38: client owner approves periods; appointed legal/privacy reviewer reviews; exact periods/text remain due before live collection. |
| UQ11 | Navigation/owner decided; content pending | D43/D52: S01/S09 links and hosted deletion request; client supplies support contact and approved pages. |
| UQ12 | Open, implementation/deployment input | Account owners, billing limits and production provisioning remain due. |
| UQ13 | Open, visual-approval input | Final icon/assets and prototype fidelity remain due. |
| UQ14 | Open, delivery/acceptance input | Date, UAT, handover and release responsibilities remain due. |
| UQ15 | Controlled paid-activation gate; route still open | D41: client approves written Play checkout-route determination before Paid activation; Razorpay preferred only where approved. |
| UQ16 | Partially answered; operational input pending | D51/D53: contact and staff provisioning approach chosen; initial people/data and review runbook remain due. |

| ID | Class | Affected modules | Why this class |
| --- | --- | --- | --- |
| UQ01 | BLOCKER | M04,M08,M09,M10,M11 | Carpool pass checks and post-expiry treatment change listing, booking and departure states. |
| UQ02 | BLOCKER | M04,M11,M13 | Existing-pass treatment changes the outcome of an admin mode change. |
| UQ03 | BLOCKER | M04,M08,M10,M11 | Shift/pass-clock transitions change driver eligibility at live workflow boundaries. |
| UQ04 | BLOCKER | M02,M13 | Required evidence and review criteria determine application and approval fields. |
| UQ05 | BLOCKER | M04,M11 | Paid package price, duration and start point determine checkout and expiry display. |
| UQ06 | DESIGN-DEPENDENT | M04,M11,M13 | Both Free and Paid variants can be documented, but first-release acceptance boundary needs confirmation. |
| UQ07 | DESIGN-DEPENDENT | M07,M09,M10,M11,M12,M13 | Draft issue categories and status flow exist; final dispute outcomes need policy. |
| UQ08 | DESIGN-DEPENDENT | M03,M05,M08,M09 | Example town records can support drafts, but actual pilot values need confirmation. |
| UQ09 | LATER | M04,M05,M06,M07,M10,M14 | Device/load targets affect validation and capacity planning, not the recorded screen rules. |
| UQ10 | BLOCKER | M02,M07,M10,M12,M13,M14 | Evidence/location retention and responsibility must be fixed before final privacy/review flows or live collection. |
| UQ11 | DESIGN-DEPENDENT | M01,M12,M14 | Support/privacy/account-deletion content can be marked pending, but cannot be approved or published empty. |
| UQ12 | LATER | M01,M04,M06,M11,M14 | Provisioning, ownership and spending limits affect implementation and release setup. |
| UQ13 | DESIGN-DEPENDENT | M01–M12,M14 | Visual reference and final assets affect approval of Android wireframes, not their functional inventory. |
| UQ14 | LATER | M01–M14 | Delivery/acceptance ownership and release artifacts concern project execution, not an additional product screen. |
| UQ15 | BLOCKER | M04,M11,M13 | Checkout route must be settled before a paid-pass flow is finalized for a Play-distributed build. |
| UQ16 | DESIGN-DEPENDENT | M02,M03,M13,M14 | Initial data, staff operation and review runbook need confirmation before operational screen approval. |
