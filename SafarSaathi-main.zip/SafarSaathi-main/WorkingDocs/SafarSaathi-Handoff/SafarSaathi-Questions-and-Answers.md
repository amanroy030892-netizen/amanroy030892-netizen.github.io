# SafarSaathi development questions and answers

12 November 2026 · Native Android pilot · `com.safarsaathi.rides`

Questions are grouped by topic and paraphrased for readability. Answers incorporate later corrections. Open items and historical commercial questions appear separately.

## Registration and driver approval

**1. What must passengers provide to book?**

A passenger verifies their mobile number with Firebase OTP and enters their name to book. They can apply to drive using the same account and continue booking while their application is under review.

**2. Can one account drive both services, including e-rickshaw carpools?**

Maintain one driver profile and approve each vehicle separately. An approved driver with an approved e-rickshaw can go on duty for on-demand rides and publish scheduled carpools using that vehicle. An approved car can be used for scheduled carpools.

**3. Which documents are reviewed and how?**

Require a profile photo, both sides of the driving licence, an RC for each vehicle and an Aadhaar document for manual admin review. Plan on a masked Aadhaar upload. QR scanning and OTP-based Aadhaar verification have not been requested.

**4. Can a driver use someone else’s vehicle?**

A vehicle registered to a family member, fleet or other owner is eligible for review. Show the registered owner’s name to the admin and request owner authorization when it differs from the applicant’s name.

**5. How are corrections handled?**

Admins can mark a specific document **Needs correction**, give a reason and notify the applicant. The applicant resubmits that document. Passenger access continues.

**6. What happens when a profile photo, licence or vehicle changes?**

Updating a profile photo leaves driving access active. A replacement licence goes back for review. Adding a vehicle requires separate RC approval. Other approved vehicles remain usable while the approved licence is valid.

## E-rickshaw decisions

**7. What opens first and when is the destination requested?**

Open on the nearby-driver map. Default pickup to the passenger’s location, allow moving the pin, and request a destination when requesting a ride.

**8. Who selects the driver?**

The passenger selects one driver and sees vehicle details. A decline or expiry lets the passenger choose another driver.

**9. When can the parties call?**

Accepting the request opens Agora calling for either participant and pauses other requests to that driver. This acceptance begins fare discussion.

**10. Who proposes and accepts a fare, including during a call?**

The driver can submit or revise the fare during the call. The passenger can accept the current amount while still on the call. Both screens retain audio through confirmation. Each acceptance refers to a specific offer version so an unseen revision cannot be booked.

**11. How does a ride start and finish?**

After fare confirmation, the driver marks arrival and enters the passenger’s four-digit pickup PIN to start. The driver marks the ride complete at drop-off.

**12. Who sees driver location?**

Available drivers show approximate public markers. After booking, only the assigned passenger sees the driver's precise live location. Break stops location sharing.

**13. Can another request arrive during negotiation, and what releases the driver?**

Either participant can cancel before pickup. A short expiry releases abandoned fare discussions. Reopen availability only if the driver is still on duty and available. See the confirmed timeout rules below.

## Carpool decisions

**14. Who may publish a carpool?**

Only registered, admin-approved drivers may publish trips, using an approved car or e-rickshaw. Driver and vehicle document requirements are recorded above.

**15. What information goes into each departure?**

Each listing is a one-way departure on a specific date. The publisher enters origin town, destination town, pickup and drop-off points, departure date and time, available seats and fare per seat.

**16. How do passengers search?**

Passengers search by town pair, date and seat count. Show trips with enough available seats, earliest departure first.

**17. How many seats may they book and who confirms?**

A passenger can reserve multiple seats in one booking. Show the total before confirmation. Confirm instantly and deduct all requested seats together. If fewer seats remain, ask the passenger to choose again.

**18. How and when do passengers pay?**

The passenger pays the driver directly at pickup by cash or UPI. Seat confirmation happens when the reservation succeeds.

**19. When can they call?**

Display fare and pickup details before booking. Enable Agora calling between the booking passenger and the driver after confirmation.

**20. When can either side cancel?**

Passengers may cancel up to 15 minutes before scheduled departure. Return the full booked seat count once. If the driver cancels the trip, notify every booked passenger and mark their bookings cancelled.

**21. How is a group boarded?**

Issue one four-digit boarding PIN per booking. The driver sees a passenger list with booked seat counts and enters the PIN at pickup to board the group.

## Rules for drivers offering both services

**22. Must a driver be on duty to receive seat bookings?**

Drivers can publish carpools and receive seat bookings while off duty or on break. On Duty controls e-rickshaw map visibility. Published trips remain searchable until full, closed, cancelled or departed.

**23. What happens before a booked carpool departs?**

If at least one carpool seat is booked, pause new on-demand requests starting 30 minutes before departure and explain the pause to the driver. Let an ongoing ride finish and prompt the driver to update waiting passengers if delayed.

**24. Can driver or vehicle schedules overlap?**

Collect estimated arrival time at publication. Use departure and estimated arrival to block overlapping carpools for either the same driver or the same vehicle.

**25. What if only some passengers arrive?**

A boarding PIN identifies the booking. The driver records the actual number boarding, including partial groups. The 15-minute cancellation cutoff still applies.

**26. When can booked passengers follow the vehicle?**

When the driver taps **On the way to pickup**, share carpool location with confirmed passengers and show when it last updated. End sharing at trip completion or cancellation.

## Live map, connectivity and timeout rules

**27. How far does the nearby search reach?**

Search for available e-rickshaws within 3 km of the selected pickup pin. If none appear, offer expansion to 5 km. Moving the pin refreshes the search around the new pickup.

**28. What happens without location permission or GPS?**

Passengers can place the pin manually and book without granting location permission. Drivers need location access and GPS to go on duty. If GPS drops during a ride, preserve the booking and tell both participants that tracking is paused.

**29. Does tracking continue with the screen locked?**

Continue location updates while on duty or sharing an active trip, including with the screen locked or another app open. Show an ongoing Android notification. Break removes the public marker. Private tracking remains available to confirmed carpool passengers once the driver selects **On the way to pickup**.

**30. What happens to stale or disconnected markers?**

Hide an available driver from the public map after 60 seconds without a fresh location. On a booked ride, display the last known position and the time since the update. Resume with a fresh position on reconnect.

**31. How long do requests, negotiations and outstanding fares remain open?**

A selected driver has 45 seconds to accept an on-demand request. Allow 5 minutes after acceptance for fare discussion. If an Agora call is still active at that deadline, let it continue. When that call ends, allow 60 seconds to accept an outstanding fare. Accepting during the call confirms the booking immediately.

## Ride alerts, calls and booking recovery

**32. What appears for an incoming ride request?**

Show the selected driver the pickup, destination, remaining request time and Accept and Decline actions. When minimized or locked, alert the driver and open the request on tap. Show expired status if the deadline has passed.

**33. How do incoming calls work on a locked phone?**

Incoming Agora calls ring with Answer and Decline, including on a locked phone. Identify the caller by first name and the associated ride. Missed or declined calls leave the booking and applicable fare timer intact.

**34. Which events trigger notifications?**

Notify the relevant participant of e-rickshaw request acceptance or decline, new or revised fares, booking confirmation, arrival and cancellation. For carpools, notify the driver of seat bookings and cancellations. Notify booked passengers when the driver heads to pickup or cancels the trip.

**35. How do alerts and fare approval work on an open screen or call?**

Update an open booking screen directly and suppress duplicate sounds. During a call show the latest fare and the passenger’s acceptance action on the call screen.

**36. How do users recover a booking after missing an alert?**

On reopening, surface the current e-rickshaw booking through an Active ride card and scheduled trips through Upcoming carpools. An old notification opens the current booking state and explains expiry or cancellation when applicable.

## Cancellations, no-shows and completion

**37. How do pre-pickup cancellations work?**

Either participant may cancel a confirmed e-rickshaw before pickup. Offer one-tap cancellation reasons, record who cancelled and notify the other participant. There is no cancellation fee. The passenger can request another ride immediately.

**38. How long does the driver wait after arrival?**

When the driver marks arrival, notify the passenger and display a five-minute wait to both. After five minutes the driver may mark a passenger no-show. Reaching the deadline alone leaves the booking open.

**39. What happens to no-shows and partial groups?**

At or after carpool departure the driver can record each booking as boarded, partially boarded or a no-show. Calculate the amount due from the actual boarded count multiplied by the booked per-seat fare. Two of three passengers boarding at ₹150 per seat owe ₹300.

**40. Can a booked departure be edited?**

Once a carpool has a booking, preserve its booked fare, route, pickup point and scheduled departure. A Running late update communicates a revised pickup arrival time. A route or schedule change requires cancelling the trip and republishing so passengers can choose the replacement.

**41. How do payment acknowledgement and completion relate?**

Show the agreed e-rickshaw fare at drop-off and each carpool group's total at boarding. Let the driver acknowledge direct payment separately from completing the ride. A completed trip can have an outstanding payment.

## Booking history, tickets and support

**42. Where do users find previous and upcoming bookings?**

My rides has Upcoming and Past tabs. Passenger mode lists the user's bookings. Driver mode lists trips they operate, with a passenger list inside each carpool trip.

**43. What appears on the ticket?**

After carpool confirmation, show the booking ID, vehicle number, pickup, drop-off, departure time, reserved seats and expected total. Show the boarding PIN on the signed-in passenger's booking screen. After boarding, show actual headcount and amount due.

**44. Can a ticket be shared or saved?**

Offer Android sharing, including WhatsApp, and Save PDF. Shared tickets and PDFs include the itinerary, vehicle number, seat count and booking ID. Exclude boarding PINs and personal phone numbers from both outputs.

**45. How do participants report issues and see the outcome?**

Passengers and drivers can report an issue from a booking, choose a category such as payment, no-show or driver conduct, and optionally add a note. Attach the booking ID automatically. The admin receives the report and sets its status to Open, In review or Resolved. The reporter sees the status and resolution note.

## Admin dashboard decisions

**46. Who has admin access and what is logged?**

Each authorized staff member signs in individually with the same admin role. Record the staff identity, timestamp and reason for document approvals, suspensions and issue resolutions.

**47. Which queues appear first?**

The dashboard opens with two queues: driver and vehicle reviews, and open booking issues. Show oldest pending items first. Highlight corrected documents and display the previous reviewer note on resubmissions.

**48. How do suspensions affect new and existing bookings?**

A vehicle suspension immediately blocks new bookings and hides listings for that vehicle. A driver suspension applies across all their vehicles. Show affected active and upcoming bookings to the admin for individual review. Allow the admin to contact participants and cancel a specific booking with a recorded reason. Suspension alone does not cancel existing bookings.

**49. How do admins investigate fare or no-show disputes?**

Search by booking ID to investigate a dispute. Show the event timeline with the accepted fare or booked seat price, arrival time, boarding count and payment acknowledgement as applicable. Keep the original booking events and add the admin’s resolution separately.

## Service area, languages and branding

**50. What is the public name and final package ID?**

Use **SafarSaathi** as the public name on Android and on tickets. The confirmed Android application ID is `com.safarsaathi.rides`.

**51. Which towns support each service?**

Admins configure the town list and enable each town independently for e-rickshaw pickups and carpool routes. No initial towns have been specified.

**52. How are carpool locations entered?**

For carpool search and publication, users select origin and destination from the searchable list of enabled towns. Drivers place a pickup pin and can add a landmark.

**53. Which languages are available?**

Both passenger and driver modes support Assamese, English and Hindi at launch, with an in-app language switch. The admin dashboard uses English.

## Home screen and role switching

**54. Which service opens on Home?**

Passenger Home opens on the e-rickshaw map. A visible E-rickshaw / Carpool switch opens carpool search by town, date and seats. Show a Resume ride card above the map when an e-rickshaw ride is active.

**55. How does Switch to Driver behave?**

Put Switch to Driver on Home. Open the dashboard for an approved driver, show Apply to drive for a new applicant, and show review status or requested corrections for a pending applicant.

**56. Can an on-duty driver switch to Passenger?**

When an idle on-duty driver switches to Passenger, ask “Go on break and switch?” On confirmation, go on break and switch roles. Keep the driver in an underway trip until it ends. Future carpool bookings remain accessible in Driver mode.

**57. Which language appears before sign-in?**

On first launch, use the phone language when it is Assamese, English or Hindi. Otherwise use English. Show a language selector on the OTP screen before sign-in.

## Maps and route guidance

**58. How is the destination communicated?**

Passengers set a destination pin and may add a landmark. Before accepting the request, the selected e-rickshaw driver sees both pickup and destination.

**59. How are nearby drivers at a stand displayed?**

Group nearby available e-rickshaw markers with a count. Tapping a group opens a list of driver names and vehicle numbers. The passenger chooses the individual driver to contact.

**60. How does a driver navigate to pickup and drop-off?**

After booking confirmation, Navigate to pickup opens the pickup coordinates in an installed maps app. After pickup PIN verification starts the ride, Navigate to destination opens the destination coordinates. Returning to SafarSaathi restores the active booking.

**61. Which distance and ETA appear before booking?**

Before booking, display an approximate straight-line distance from the driver to the passenger's selected pickup, for example “About 800 m from pickup.” The navigation app provides road ETA and turn-by-turn guidance in the first release.

## Development environments and Play release plan

**62. Which Firebase project and environments will we use?**

Use Firebase emulators for local development, a separate Firebase test project for two-phone GPS, calling and notification tests, and a new client-owned Firebase production project for launch. Prototype data migration is outside the current plan.

**63. Will the previous Play listing be reused, and which application ID was chosen?**

The client plans to delete the previous Play listing and create a new app. Use `com.safarsaathi.rides` for the release build, production Firebase Android registration and new Play listing.

**64. Have these services or the new listing been provisioned?**

These are setup decisions. Firebase provisioning and Play Console actions are pending.

## Offline booking behavior

**65. Which details remain available offline?**

The signed-in passenger can open their last synced active ride or upcoming ticket offline, including pickup details, vehicle number and boarding PIN. Show the last sync time.

**66. What if a booking or fare confirmation loses its response?**

If connectivity drops after Book seats or Accept fare, show Checking booking status. On reconnect, resolve the original action against the server. Open the booking if it succeeded. Otherwise show current seat availability or the current fare and let the passenger decide whether to retry.

**67. Can the passenger or driver be offline during PIN verification?**

The passenger may present the cached PIN offline. The driver needs connectivity to verify it before starting an e-rickshaw ride or boarding a carpool group. Keep the booking open and offer Retry verification if the driver loses signal.

**68. Can completion or payment receipt be recorded offline?**

The driver can record completion and payment receipt separately offline. Persist each action locally as Pending sync and retry on reconnect. Surface a conflict for review if an intervening admin change conflicts with the action.

**69. How does offline cancellation interact with the cutoff?**

Carpool cancellation requires connectivity. Seats remain reserved until the server confirms cancellation. Evaluate the 15-minute cutoff against server receipt time.

## Passenger booking limits

**70. Can a passenger request a second e-rickshaw?**

A passenger may have one active e-rickshaw request or ride at a time. A decline, expiry or cancellation releases the request; completion releases an active ride.

**71. Can someone reserve seats without travelling?**

The booking passenger travels with their carpool group, holds the boarding PIN and serves as the driver’s contact for all seats.

**72. Can a passenger change the seat count?**

Allow online seat-count edits to the existing booking until the 15-minute cutoff. Show the revised total before confirmation. Confirm an increase only if all extra seats remain available; release removed seats upon confirmation of a decrease. Preserve the booking ID and PIN.

**73. Can a passenger book overlapping trips or their own departure?**

Block a passenger from booking overlapping carpools using departure and estimated arrival times. Prevent a driver from booking their own published trip. Permit a return departure at or after the first trip’s estimated arrival.

## Driver shifts and availability

**74. Which e-rickshaw goes on duty?**

Going On Duty selects one approved e-rickshaw. Automatically select the sole approved e-rickshaw; otherwise let the driver choose. To change vehicles, resolve any current request or ride, go on break and select the next vehicle.

**75. When does the shift expire, and what happens to ongoing work?**

End on-demand availability after twelve hours. With Free pass selected, a driver can start a fresh shift manually. With Paid pass required, restarting a shift cannot extend paid access. Let an underway ride finish. Future carpool listings continue under their existing booking rules.

**76. When does the driver become visible after completion?**

Restore public availability after completion has synced, provided GPS is fresh and the driver is still eligible and on duty. Offer Finish and take a break so the driver can complete a ride without becoming available again.

**77. Are schedule conflicts checked across passenger and driver roles?**

Check the account’s carpool schedule across passenger and driver roles when publishing or reserving. Block overlapping commitments in either order using departure and estimated arrival times.

## Vehicle capacity, shared vehicles and document renewal

**78. Who sets passenger capacity?**

At vehicle approval, the admin records passenger capacity excluding the driver. Published seat counts for cars and e-rickshaws cannot exceed this capacity.

**79. Can multiple approved drivers share a vehicle?**

Multiple approved drivers may share a family or fleet vehicle. Approve each driver for that vehicle individually. Identify the shared vehicle by registration number and prevent simultaneous duty sessions or overlapping carpool listings for it across drivers.

**80. What happens before and at document expiry?**

Record driving licence and RC expiry dates during review. Notify the driver 30 and 7 days before expiry. An expired licence blocks new work for the driver; an expired RC blocks new work for that vehicle. Allow an underway ride to finish and flag upcoming bookings for individual admin review.

**81. Can a driver renew documents early?**

Accept early renewal uploads. The current approval remains valid until expiry during review. An approved renewal supplies the new expiry date. If the old document expires before approval, pause new work until the replacement is approved.

## Driver discovery passes

**82. Who decides whether a driver pass is free or paid?**

The app is free to download. An authorized admin can switch between Free pass and Paid pass required. Launch in free mode. In paid mode the driver buys the shared pass through Razorpay. ₹100 for 12 hours is an example package.

**83. Does taking a break pause the pass?**

No. A 12-hour pass runs continuously from issue in free mode or purchase in paid mode, including breaks and offline time. Show the expiry to the driver.

**84. Does one pass cover both services?**

Yes. One driver pass covers e-rickshaw discovery and carpool access under either admin setting. Passenger ride fares are paid directly to the driver.

**85. Is a valid pass required at publication or at departure?**

Awaiting explicit confirmation. The suggestion was to check at publication and let an already-published trip receive bookings and depart after expiry.

**86. Which gateway handles paid passes and when is a pass granted?**

Use Razorpay. The server verifies successful payment before issuing the pass once. Pending or failed payments do not grant a paid pass. The final package catalogue is open.

## Original discovery and handover questions

**87. Confirm ₹15,000, native build and deadline. When does the clock start? If scope exceeds it, which feature must launch first?**

The user asked to set quotation aside and plan development. Native Android is confirmed. A binding delivery date, start date and fallback priority were not established in discovery.

**88. Confirm existing listing, icon and design source. Is exact HTML screen parity required?**

Use the HTML prototype and supplied assets as references. A new listing is planned. Exact screen parity and final icon asset remain open.

**89. Which towns and stands will the admin enable first, and which Android devices should be tested? Expected pilot drivers, passengers, OTPs/day and driver-hours?**

Admins configure service towns. Initial towns, stands, target phone models and usage estimates remain open.

**90. Who owns Firebase/Maps billing, Agora and Play accounts? What recurring spend is acceptable? Does the project contain real users or trips to migrate?**

Use new client-owned production Firebase and separate test infrastructure. No prototype migration is planned. Detailed billing ownership for other services and spend limits remain open.

**91. Which passenger details are mandatory? Which driver documents and selfie are required? Is manual review of masked evidence sufficient, who reviews it, and when should evidence be deleted?**

Passenger phone OTP and name; driver document review as described above. Retention period and whether a live selfie is required beyond a profile photo remain open.

**92. Driver selected from radar or automatic dispatch? Which radius, stand grouping and pickup/drop input? Is address search, ETA or in-app navigation essential?**

Passenger selects one driver; 3 km, expandable to 5 km; grouped markers, pins, landmark and external navigation. Address autocomplete was not committed.

**93. Is private Agora voice mandatory, including incoming calls with the screen locked? If not, may a confirmed booking expose phone numbers for normal calls?**

Agora private calls are confirmed, including locked-screen ringing. A fallback exposing phone numbers was not selected.

**94. Who enters the negotiated fare, who confirms, who can cancel, after how long does a request expire, and is a separate ride-start PIN required?**

Driver proposes; passenger accepts the displayed fare. Request, fare, cancellation and pickup PIN rules are documented above.

**95. When is GPS visible while driving, on break and screen-off? The approved on-demand shift limit is 12 hours. Can drivers serve carpool and rickshaw simultaneously?**

Both services can be operated by eligible drivers. The 12-hour shift, screen-off tracking and carpool buffer are confirmed.

**96. Are carpools one-off departures between named towns? Who may publish? Can users book multiple seats? Instant reservation or driver approval?**

One-off trips by approved drivers with approved cars or e-rickshaws. Instant multi-seat booking is confirmed.

**97. Pay at pickup or prepaid direct UPI? When is a seat held, released or ticketed? Who handles unpaid bookings, late cancellations, refunds and disputes? Keep the 15-minute cutoff?**

Direct cash or UPI at pickup, instant reservation, 15-minute cutoff and a booking-linked dispute workflow. A refund adjudication policy was not specified.

**98. Which tickets and operating tools are required at launch: booking detail, WhatsApp share, PDF, driver review, suspension, ride lookup, support/contact or incident reporting?**

Booking details, Android sharing, PDF tickets, driver review, suspension, booking lookup and issue handling are confirmed.

**99. What is the launch and future revenue model?**

Start with free driver passes. The admin can turn paid passes on or off; the download remains free. Please confirm what happens to passes already issued when the setting changes.

**100. Who supplies policy text and support contact, performs UAT and signs off? Is delivery APK-only, a Play-ready AAB, or submission through the client's Play Console? What post-handover support is included?**

New Play listing planned. Policy author, support contact, UAT owner, sign-off, final handover deliverables and support period remain open.
