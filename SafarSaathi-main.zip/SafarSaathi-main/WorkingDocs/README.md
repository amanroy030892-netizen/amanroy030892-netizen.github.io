# Working Docs

Keep drafts, meeting notes, experiments, and temporary research here. Move finalized material to `Docs` or `Planning`, and remove obsolete drafts.

## Current working material

- [SafarSaathi handoff](SafarSaathi-Handoff/README.md) — planning inputs for the next review pass.
