# Phase 3 — journey coverage and decision report

**Review baseline:** 12 November 2026. This validates [USER_JOURNEYS.md](USER_JOURNEYS.md), [NAVIGATION_ARCHITECTURE.md](NAVIGATION_ARCHITECTURE.md), [SCREEN_TRANSITIONS.md](SCREEN_TRANSITIONS.md), and [LIFECYCLE_STATE_MACHINES.md](LIFECYCLE_STATE_MACHINES.md) against the unchanged [Phase 2 screen inventory](SCREEN_INVENTORY.md). `R` and `D` are accepted planning requirements/decisions, **not client-validated**; the separate client confirmation form remains unsigned. No wireframes, datasets or application code were made.

## Structural and journey coverage

| Check | Result | Evidence / limitation |
| --- | --- | --- |
| Existing screen IDs | **62/62** have exactly one row in SCREEN_TRANSITIONS.md: S01–S11 (11), P01–P16 (16), D01–D23 (23), A01–A12 (12). | Automated ID comparison against SCREEN_INVENTORY.md found no missing or extra transition IDs. |
| Entry paths | **62/62** have a named source/entry condition. | A route-reference graph from ROOT→S01/A01 and PUSH→S07 reaches all 62 IDs; normal hub, task, alert and status routes are listed per row. No existing screen is structurally unreachable. D05's final rejected state has no approved recovery action, which is a policy gap rather than an unreachable screen. |
| Primary action outcomes | Every transition row names success and error/rejection destinations or a state on the same screen. | Pending writes resolve via S08/P12/D09 rather than being treated as success. Secondary actions use the guards in the screen inventory/navigation contract. |
| End-to-end role journeys | **13/13** journeys have a completion or defined waiting/failure state. | J01–J13 cover new/existing passengers, applicant and driver statuses, active driver, carpool supply/demand/operation, admin, support, paid passes and offline recovery. UQ-gated branches remain unapproved. |
| Unauthorized access | Protected routes recheck identity, role, membership and action eligibility on entry/resume/write. | P13/P15 only booking participant; D13/D18/D21 only assigned/owning driver; A02–A12 authorized staff. Back and deep links return to safe Home/sign-in when a gate fails. R01,R20–R21,R23; D03,D23–D26. |
| Back/deep-link behavior | No Back path bypasses approval, pass, duty, booking membership or PIN verification. | S07 resolves latest server state; S05 blocks departure from underway driver work; P05/P06 and D11/D12 remain authoritative after UI close. R06–R10,R18,R23; D08–D13,D26. |
| Cycles and dead ends | No **unintended** navigation loop or trapped screen found. | Home↔history, detail↔issue, and draft↔review are intentional, user-exitable routes. S07/S08/P12/D09 have explicit success, retry and safe-exit states. A rejected driver has a defined safe passenger route, but no appeal action is specified. |
| Cross-feature consistency | Core transitions are aligned across both Android roles and admin. | Fare version/booking, seat inventory/PIN, completion/receipt, suspension/affected bookings, pass/duty and offline reconciliation are paired in the lifecycle tables. R06–R24; D08–D27. |

The checks establish **documentation coverage**, not user testing or client sign-off. A route can be structurally complete while its final business policy remains blocked below.

## Critical cross-module dependencies

| Dependency | Journey consequence | Trace |
| --- | --- | --- |
| M01 identity → M02 approval → M11 pass → M04 duty | A signed-in passenger can apply to drive, but new driver work needs separate person, vehicle, document, pass and duty gates. | R01–R04,R10,R24; D03–D06,D13,D25,D27 |
| M03 towns + M04 presence → M05 discovery → M06 fare → M07 ride | Search and request depend on eligible, fresh public presence; only a version-safe fare creates an assigned ride. | R05–R09,R22; D07–D12,D29 |
| M08 listing/schedule → M09 atomic seats → M10 boarding | Capacity, vehicle/account conflicts and fixed booked terms precede reservation; actual boarding changes due total, not booked price. | R04,R11–R16; D14–D21,D25 |
| M14 recovery across M05–M13 | Alerts, uncertain fare/seat actions, online PIN and queued completion/receipt must open current authoritative state. | R18,R23; D26 |
| M12 owned history/issues → M13 admin audit | Tickets and issues use original booking events; staff resolutions and suspensions are separate attributable events. | R19–R21; D22–D24 |

## Unresolved decision recommendations — **not approvals**

The following seven are Phase 2 **BLOCKER** questions. Each recommendation is a design proposal only; retain alternative branches in the next draft until the client/product owner confirms it. Screen impact is the exact existing-ID map; the [Phase 2 impact table](WIREFRAME_EXECUTION_PLAN.md#question-to-screen-impact-map) covers UQ06–UQ16 as well.

| UQ / affected journeys and screens | Why it matters; conditional branches | Recommendation and rationale — **unapproved** |
| --- | --- | --- |
| **UQ01** J05,J07–J09,J13; D01,D07,D16–D18,D21,P10–P11,P13,A12 | A carpool may need a pass at publication, at booking, at departure, or more than once. Expiry could hide a listing, block new seats, or disrupt confirmed riders. | **Propose** checking eligibility at publication and preserving already-published departures/bookings after pass expiry, including their existing seat availability, as the handoff's own suggestion. This avoids cancelling passenger plans because a driver's access clock ends. Confirm separately whether any listing horizon is needed; none is approved. Q85; R11,R16,R24; D14,D19,D27. |
| **UQ02** J05,J11,J13; D01,D07–D10,D16–D18,A12 | Free↔Paid can revoke, preserve or replace existing entitlements. Each produces different dashboard and gate states. | **Propose** honoring an issued pass until its recorded expiry and applying the new mode to subsequent issuance. This avoids silent loss/extension of previously shown access. The handoff mentions this only as a suggestion. Q99; R24; D27. |
| **UQ03** J05–J07,J09,J13; D01,D07,D10,D13,D16–D18,D21,A12 | A restarted 12-hour shift, a continuous pass and mid-trip expiry are distinct clocks; treating them as one changes availability and scheduled-work results. | **Propose** modeling independent shift and entitlement expiries. New on-demand work requires both; shift restart in Free mode rechecks the free entitlement, and no restart extends a paid pass. Underway e-rickshaw ride finishes as confirmed; carpool expiry handling follows the eventual UQ01 decision. This preserves Q75/Q83 without inventing a combined clock. R10,R24; D13,D27. |
| **UQ04** J03–J04,J11; D02–D05,A02–A04 | Masking, live selfie and sufficient manual evidence determine required fields, review states and private storage. | **Propose** masked Aadhaar for manual review and no live selfie unless the reviewer/privacy owner explicitly requires it; define a written reviewer checklist. This follows Q03's tentative masking plan while minimizing unconfirmed collection. Final evidence requirement remains open. R02; D05; Q03,Q91. |
| **UQ05** J05,J13; D01,D07–D10,A12 | Price, duration and entitlement start determine checkout, expiry display and shift/pass tests. | **Propose** approving a small explicit package catalogue before paid wireframe approval, with each package's price, duration and start event. Starting at verified grant is a candidate to evaluate, not a decision; ₹100/12 hours remains an example only. R24; D27; Q82,Q86. |
| **UQ10** J03–J04,J06,J09,J11–J12; D03–D04,D06,D13,D21,P07,P15,S08,A03–A04,A08 | Evidence and precise-location retention/deletion, policy and reviewer ownership affect collection, access, cached views and audit. | **Propose** that the designated data owner/reviewer approve explicit retention periods and deletion triggers before production evidence collection; avoid specifying a duration in design without that approval. R02,R09,R23,R26; D05,D12,D31; Q91. |
| **UQ15** J05,J11,J13; D07–D09,A12 | Razorpay is selected for paid passes, but the distributed build's applicable Play checkout route is not confirmed. A wrong route would invalidate the paid flow. | **Propose** a documented Play distribution/payment-policy decision before finalizing A12/D08/D09 or activating Paid mode. Preserve Razorpay as the planning gateway while evaluating how it can be used in the approved distribution route; do not treat it as policy clearance. R24; D27; Q86; project-plan open decision. |

**Other unresolved inputs:** UQ06 first paid-release boundary affects J05/J13; UQ07 issue/cancellation/payment policy affects J02,J08–J11; UQ08 initial towns affects J02,J07–J08,J11; UQ09 target devices/load affects J02,J06,J09,J12 validation; UQ11 legal/support content affects J01/J10; UQ12 account owners affect environment setup; UQ13 assets/prototype fidelity affects later visual approval; UQ14 delivery/UAT affects release; UQ16 operational runbook affects J04/J11. None is silently answered here. Their classes and affected modules remain in [UNRESOLVED_QUESTIONS.md](UNRESOLVED_QUESTIONS.md).

## Missing or redundant screen recommendations — separate from inventory

**No existing ID is unreachable or demonstrably redundant.** The following are review proposals, not changes to the 62-screen inventory or approved scope.

| Finding | Existing route impact | Recommendation before wireframing |
| --- | --- | --- |
| Privacy, help/support and account-deletion entry points are absent, though hosted content is planned. | J01/J10; S01,S09,P01,D01; UQ11; R26/D31. | Confirm content, audience and whether links should be available before OTP and after sign-in. Update the inventory explicitly if a dedicated Android or hosted page must be counted; do not assign a new ID silently. |
| Passenger profile management beyond required name entry is not specified. | J01/J03; S03,P01; R01/D03. | Confirm whether viewing/editing the name or phone is required. If not, retain S03 as the only passenger identity surface; do not invent a profile screen. |
| Final driver rejection, appeal and reapplication are not defined. | J04; D05,A03–A04; R02/D06. | Decide whether “rejected” is terminal, correctable, or appealable; update D05/A03–A04 states and any additional route only after explicit approval. |
| Admin sign-in method and recovery are unspecified. | J11; A01; R20/D23/Q46. | Choose authentication and session-recovery method before designing credential fields; add a recovery screen only if that choice requires one. |
| E-rickshaw direct-payment timing is not fixed. | J02/J06; P07,D15; R17/D28/Q41. | Decide when cash/UPI is normally requested while keeping receipt independent of ride completion. |
| Final issue categories, cancellation reasons and dispute outcomes are unspecified. | J02,J08–J11; S10,P08,P14,D22,A06; UQ07. | Approve policy and wording before finalizing options; keep direct-pay disputes separate from paid-pass purchase support. |
| Admin contact method for affected booking participants is unspecified. | J11; A10; R21/D24/Q48. | Confirm whether existing contact tools or a new admin communication route will be used before detailing the A10 action; do not expose phone numbers through public booking surfaces. |
| Published carpool “closed” status and unbooked edit control lack an action definition. | J07; D18; Q22,Q40. | Confirm whether closure is only an automatic search state and exactly which pre-booking fields can be edited. Avoid adding a close button or extra screen until decided. |

## Before beginning data modeling

1. Resolve UQ01–UQ05, UQ10 and UQ15 with explicit decision owners and record any changed R/D rule. Set UQ06's first-release acceptance boundary without dropping the paid-pass pilot scope by implication.
2. Decide the missing admin sign-in, legal/support entry, rejection, payment-timing, issue/cancellation and carpool-closure details above. Update the approved screen inventory **only if** a new surface is actually required.
3. Use the nine lifecycle tables as a review checklist for actor, precondition, authoritative deadline, idempotent retry, membership and audit. Then specify data ownership/events for the same cross-role booking examples in the [Phase 2 execution order](WIREFRAME_EXECUTION_PLAN.md).
4. Obtain client validation of the planning baseline before treating these routes or recommendations as approved requirements. The five Phase 3 documents remain design proposals until then.
