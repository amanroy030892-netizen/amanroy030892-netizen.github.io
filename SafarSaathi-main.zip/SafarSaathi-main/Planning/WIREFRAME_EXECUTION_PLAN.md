# Phase 2 — dataset and wireframe execution plan

**Purpose:** This is the recommended order and review contract for the *next* design phase. No wireframes, datasets, journey maps, UI code or application code are created here. It uses the 14 modules in [feature architecture](FEATURE_MODULES.md), 62 IDs in [screen inventory](SCREEN_INVENTORY.md), and dependency gates in [feature dependencies](FEATURE_DEPENDENCIES.md). All R/D/Q references describe the accepted planning baseline; the [client confirmation form](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Client-Confirmation.docx) has no recorded sign-off. No requirement below is labeled client-validated.

## Work packets for the next phase

Each packet pairs a **future example-record specification** with the corresponding **future wireframe set** so that screens across roles describe the same booking and eligibility states. Example records are proposed test inputs, not real user data, implementation schemas or new product scope. Complete the listed dependency contract and decision gate before seeking approval of the packet.

| Order | Modules and future example-record specification | Screen IDs to wireframe together | Review evidence / gate | Source |
| --- | --- | --- | --- | --- |
| **1. Shared foundation** | M01,M14 core: signed out, OTP verified/name missing, passenger/applicant/approved driver, three languages, denied passenger location, denied driver location, stale notification, offline cached booking, uncertain write. | S01–S05,S07–S09,A01 | Same account and active work survive language/role change; notification resolves latest state; manual pickup path exists. Admin sign-in method remains unspecified. | R01,R18,R22–R23; D01–D03,D23,D26; Q01,Q28,Q36,Q53–57,Q65–67 |
| **2. Eligibility and service area** | M02,M03,M11 Free-pass branch,M04: two town enablement combinations; applicant with corrected licence; approved person with one car and one e-rickshaw; shared registration; capacity/expiry; Free pass and shift at 0/12 hours. | D01–D07,D10,A02–A04,A11–A12 | Person/vehicle/pass/duty are visibly separate; 30/7-day and scope-specific expiry; UQ04 and UQ10 block final evidence review; UQ01–UQ03 block final pass transitions. | R02–R04,R10,R22,R24; D04–D06,D13,D25,D27,D29; Q02–06,Q51,Q74–85 |
| **3. E-rickshaw two-phone journey** | M05,M06,M07,M11 direct receipt,M14 integrations: two passenger accounts, one available driver, 3/5 km, request acceptance/decline/45-second expiry, revised fare versions, active call past five minutes, arrival/wait/PIN, GPS loss, completed/outstanding payment. | P01–P08,D11–D15,S06–S08 | Passenger and driver see one authoritative booking/fare; stale offer rejected; no-show requires explicit action; driver PIN verification online; completion/receipt separate. | R05–R10,R17–R18,R23,R25; D07–D13,D18,D26,D28,D30; Q07–13,Q27–38,Q41,Q60–61,Q65–68,Q70,Q76 |
| **4. Carpool supply and reservation** | M08,M09,M14: enabled town pair; approved car/e-rickshaw; one-way departure and estimated arrival; passenger/driver/vehicle overlap; one booking, last-seat race, seat increase/decrease, server cutoff, driver cancellation. | D16–D18,D22,P09–P14 | Capacity and schedules reconcile across both roles; a booked trip's fixed fields remain fixed; booking ID/PIN survive edits; cancellation cannot release seats offline. UQ01 blocks final pass gate. | R04,R11–R13,R15–R16,R23; D14–D17,D20,D25–D26; Q14–24,Q40,Q69–73,Q77–79 |
| **5. Carpool pickup and settlement** | M10,M11 direct receipt,M14: three-seat booking/two boarded; no-show; private tracking on/off; T−30 on-demand pause; queued receipt/completion. | D19–D21,P15 plus P13,S06,S08 states | One PIN per group; due amount uses actual boarded count; pass and shift transitions do not erase underway work. UQ01/UQ03 block final eligibility at departure. | R14,R16–R17,R23; D18–D21,D26,D28; Q21,Q23,Q25–26,Q39–41,Q67–68 |
| **6. History, support and admin** | M12,M13: owned upcoming/past, private ticket vs share/PDF, issue statuses, booking event history, one-vehicle/whole-driver suspension, affected-booking review, individual cancellation reason. | P16,D23,S10–S11,A05–A10 plus P13 | Export has no PIN or phone; immutable trip events stay separate from admin action; existing booking is not auto-cancelled. UQ07 and UQ16 need policy/operation confirmation before approval. | R19–R21; D22–D25; Q42–49,Q80 |
| **7. Paid-pass and release variants** | M11 paid branch plus M04/M08/M09/M13/M14 rechecks: catalogue, purchase pending/failed/success, duplicate notice, pass expiry, Free → Paid → Free, already-issued pass, paid checkout route. | D07–D09,A12 plus D01,D10,D16–D18,P10–P11 | Server verification issues one entitlement; no entitlement for pending/failed. UQ01–UQ03,UQ05–UQ06,UQ15 must be resolved for approval and release placement. This remains in the planned pilot, even though first-release activation is open. | R24; D27; Q82–86,Q99; project-plan pass acceptance |

## Review protocol for each packet

1. Start from the R/D/Q citations in [screen inventory](SCREEN_INVENTORY.md). Preserve the distinction between the accepted internal baseline and client-validated requirements. No client validation is recorded yet.
2. For each future screen draft, pair a normal, empty/loading, permission/eligibility denial, stale/expired, and relevant offline/error state with the same example booking or driver record. Mark a state “not applicable” when it truly has no entry path.
3. Record each assumed answer next to the affected screen and UQ ID. **BLOCKER** cases may be drafted as labeled alternatives but cannot be finalized; **DESIGN-DEPENDENT** cases need confirmation before approval. Do not silently promote a suggested answer, such as “pass checked at publication” or “existing passes honored until expiry.”
4. Review both ends of every transaction together: request/offer, seat reservation, PIN verification, completion/receipt, issue resolution, suspension. Verify entry/exit and event consistency across passenger, driver and admin views.
5. At packet approval, check the screen list against the 62-ID inventory and the module ownership map. Any proposed additional feature or screen must be called out as a scope change with its source or a new explicit decision.

## Question-to-screen impact map

This table gives exact screen IDs for each item in [unresolved questions](UNRESOLVED_QUESTIONS.md). A range includes every numbered screen in the range. “None” means the input affects implementation, launch or an external hosted page rather than a screen in the requested Android/admin inventory. Classifications are copied from the unresolved list and do not change its question wording or status.

| Question / class | Affected modules | Exact affected screens or screen boundary | Design gate |
| --- | --- | --- | --- |
| **UQ01 BLOCKER** | M04,M08,M09,M10,M11 | D01,D07,D16–D18,D21,P10–P11,P13,A12 | Pass validity at publication/booking/departure and post-expiry listing state. |
| **UQ02 BLOCKER** | M04,M11,M13 | D01,D07–D10,D16–D18,A12 | Existing-pass outcome on Free/Paid switch. |
| **UQ03 BLOCKER** | M04,M08,M10,M11 | D01,D07,D10,D13,D16–D18,D21,A12 | Shift/pass-clock interactions and underway work. |
| **UQ04 BLOCKER** | M02,M13 | D02–D05,A02–A04 | Evidence fields and review criteria; owner authorization already confirmed. |
| **UQ05 BLOCKER** | M04,M11 | D01,D07–D10,A12 | Paid catalogue and entitlement start/expiry. |
| **UQ06 DESIGN-DEPENDENT** | M04,M11,M13 | D07–D09,A12; D01,D10 for release-mode variants | First-release paid checkout acceptance boundary. |
| **UQ07 DESIGN-DEPENDENT** | M07,M09,M10,M11,M12,M13 | S10–S11,P07–P08,P13–P14,D13,D15,D20–D21,A05–A08 | Issue taxonomy, unpaid/no-show/dispute resolution and any adjudication. |
| **UQ08 DESIGN-DEPENDENT** | M03,M05,M08,M09 | P01–P02,P09–P10,D17,A11 | Actual town/stand content and service enablement. |
| **UQ09 LATER** | M04,M05,M06,M07,M10,M14 | S04,S06–S08,P01,P07,P15,D10–D11,D13,D21 | Target-device and load validation, including lock-screen/GPS behavior. |
| **UQ10 BLOCKER** | M02,M07,M10,M12,M13,M14 | D03–D04,D06,D13,D21,P07,P15,S08,A03–A04,A08 | Private evidence and precise-location handling/retention. |
| **UQ11 DESIGN-DEPENDENT** | M01,M12,M14 | **None in this inventory**; externally hosted privacy/support/account-deletion content is in R26/D31. S01/S09 entry links are not specified by the handoff. | Content and any Android entry point require a product decision before final approval. |
| **UQ12 LATER** | M01,M04,M06,M11,M14 | S02,S04,S06,P01,D08–D09,D10 (service setup/testing); no new screen implied. | Account provisioning and spend limits before implementation/release. |
| **UQ13 DESIGN-DEPENDENT** | M01–M12,M14 | S01–S11,P01–P16,D01–D23; no admin-parity requirement is recorded. | Brand/icon and old-prototype fidelity for Android visual approval. |
| **UQ14 LATER** | M01–M14 | **None**; schedule, UAT ownership, signing and handover are project/release concerns. | Agree project acceptance and release artifacts. |
| **UQ15 BLOCKER** | M04,M11,M13 | D07–D09,A12 | Play-distributed paid checkout route. |
| **UQ16 DESIGN-DEPENDENT** | M02,M03,M13,M14 | A02–A04,A09–A11,D05–D06,S07; A12 where initial pass-mode operation is documented. | Initial records, staffing and review runbook. |

## Additional specification gaps surfaced by the screen inventory

These are **missing detail**, not new functionality or answered decisions. They should be reviewed with the relevant existing UQ or added as explicit questions in a later decision review; this Phase 2 task does not amend the original unresolved questions.

- **Admin sign-in method and recovery** are not described beyond individual authorized staff sign-in (A01; M01; Q46). No credential method is assumed.
- **Privacy/support/account-deletion entry points** from Android and the exact hosted page content are absent (UQ11; R26/D31). The project plan proposes hosting those pages but does not specify a navigation surface.
- **Exact e-rickshaw direct-payment timing** is described as pickup/ride end as applicable, while carpool is at pickup; no universal collection moment is defined (M07/M11; R17; Q18,Q41). The receipt remains separate from completion.
- **Issue category list, cancellation-reason list, and direct-payment dispute outcomes** are not finalized (UQ07; S10,P08,A06). Example categories and one-tap reasons in the handoff do not constitute a final taxonomy.
- **First paid-release boundary** remains unresolved even though the pilot plan includes paid-mode acceptance (UQ06). This must be decided before assigning final release acceptance, without silently reducing the pilot.
