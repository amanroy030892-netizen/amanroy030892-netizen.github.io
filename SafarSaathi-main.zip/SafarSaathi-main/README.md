# SafarSaarthi

SafarSaarthi is a ride pooling app. This repository keeps the implementation and its supporting documents together.

## Repository structure

| Folder | Purpose |
| --- | --- |
| [Code](Code/README.md) | Implemented app and supporting code. |
| [Docs](Docs/README.md) | Current, approved project documentation. |
| [WorkingDocs](WorkingDocs/README.md) | Drafts, notes, and temporary research. |
| [Planning](Planning/README.md) | Product plans, roadmap, milestones, and decisions. |

Move a finished draft from `WorkingDocs` into `Docs` or `Planning` so each document has one authoritative home.
