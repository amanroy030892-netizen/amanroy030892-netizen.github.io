# Planning

Keep product vision, requirements, roadmap, milestones, and decision records here. Use GitHub Issues or Projects for frequently changing task status.
