# Phase 4 — technical architecture

**Status:** implementation-ready design proposal, 13 November 2026; internal planning baseline, not signed client validation. [Decision register](DECISION_REGISTER.md) is authoritative for product choices. [Unresolved questions](UNRESOLVED_QUESTIONS.md) is authoritative for outstanding inputs. No Firebase project or production resource is created by this design.

## Reconciliation before schema design

[DATA_MODEL_READINESS_REPORT.md](DATA_MODEL_READINESS_REPORT.md) records D33–D53 and proposes amendments to existing screen actions/states and Phase 3 lifecycles. Those later confirmed decisions supersede the older conditional UQ branches in [USER_JOURNEYS.md](USER_JOURNEYS.md), [SCREEN_TRANSITIONS.md](SCREEN_TRANSITIONS.md), and [LIFECYCLE_STATE_MACHINES.md](LIFECYCLE_STATE_MACHINES.md). The 62 IDs remain fixed. The exact proposed inventory/lifecycle edits are in [DATA_MODEL_VALIDATION_REPORT.md](DATA_MODEL_VALIDATION_REPORT.md); the Phase 3 files are left as historical baseline until a separate inventory approval. In particular, D33 preserves published carpools after pass expiry, D34 honors issued passes, D35 separates pass/shift clocks, D36 requires masked Aadhaar without a separate live selfie, D44 allows admin reopening of the same rejected application, D45–D50 fix fare/cancellation/issues, and D52 stages deletion. Neither the unsigned client confirmation nor a pending external review is represented as approval.

## Stack and boundaries

| Layer | Design | Status and boundary |
| --- | --- | --- |
| Android | One native Kotlin app, package `com.safarsaathi.rides`, Jetpack Compose, Firebase Android SDKs, local encrypted pending-action store and Firestore offline cache; Assamese/English/Hindi | D01–D02 confirmed; passenger and driver are modes of one Auth identity. |
| Admin web | Vue 3, TypeScript, Vite, Vuetify 3, Firebase Auth, Hosting | **Proposed technical choice**; no conflicting approved web framework found in the project/pilot plans, which specify only an English admin dashboard. |
| Durable data | Cloud Firestore | Authoritative profiles, approvals, bookings, passes, payment records, issues, configuration and audit. See [Firestore model](FIRESTORE_DATA_MODEL.md). |
| Ephemeral data | Realtime Database | Live presence and active coordinates only. See [RTDB model](REALTIME_DATABASE_MODEL.md). |
| Private files | Cloud Storage for Firebase | Evidence and support attachments; never public URLs. See [storage design](STORAGE_ARCHITECTURE.md). |
| Operations | Cloud Functions v2, Node.js 22 + TypeScript, Cloud Scheduler where needed | Node.js 22 is supported in [Firebase runtime guidance](https://firebase.google.com/docs/functions/manage-functions). All high-risk state mutations are server-authoritative. |
| Alerts/calls/maps | FCM, short-lived server-issued Agora tokens, Google Maps display and external installed navigation | Push is a hint; authoritative record is reloaded. Agora and Maps account ownership/cost remain UQ12. |
| Protection/test | Auth, rules, App Check, server checks, Emulator Suite, separate test and client-owned production projects | App Check is abuse reduction, never an authorization substitute. D31 setup remains pending. |
| Driver-pass payment | Razorpay conditional integration | D40 requires a tested paid path in first release; D41 requires written checkout-route approval before production Paid activation. Passenger fares remain direct cash/UPI. |

```mermaid
flowchart LR
  A[Android passenger and driver] --> AU[Firebase Auth]
  W[Vue admin on Hosting] --> AU
  A --> CF[Cloud Functions v2]
  W --> CF
  A --> FS[(Firestore)]
  W --> FS
  A --> RT[(Realtime Database)]
  CF --> FS
  CF --> RT
  A --> ST[(Private Storage)]
  W --> ST
  CF --> ST
  CF --> FCM[FCM]
  CF --> AG[Agora token service]
  CF --> RP[Razorpay conditional]
```

Client reads are limited to membership-scoped or public projections. Server SDK bypasses rules, so each function must authenticate, authorize, validate input, enforce lifecycle and tenant ownership, and audit privileged effects. Configuration is versioned; a displayed mode or balance is never authority for a write. Firestore transactions protect cross-document seat/assignment invariants; RTDB location is deliberately non-transactional with durable booking state.

## Source of truth and navigation

- [DATA_SCHEMA_DEFINITIONS.md](DATA_SCHEMA_DEFINITIONS.md) defines typed fields, validation and lifecycle enums; [entity catalog](DATA_ENTITY_CATALOG.md) defines ownership, trace and retention. Both use stable E IDs.
- [CLOUD_FUNCTIONS_ARCHITECTURE.md](CLOUD_FUNCTIONS_ARCHITECTURE.md) defines callable, webhook and scheduled contracts. [DATA_OPERATIONS_AND_SYNC.md](DATA_OPERATIONS_AND_SYNC.md) defines transaction boundaries and retry semantics.
- [SCREEN_DATA_MAPPING.md](SCREEN_DATA_MAPPING.md) maps S01–S11, P01–P16, D01–D23 and A01–A12 to the same entities and functions. [ENTITY_RELATIONSHIPS.md](ENTITY_RELATIONSHIPS.md) shows references and non-relational integrity rules.
- [AUTHORIZATION_AND_SECURITY.md](AUTHORIZATION_AND_SECURITY.md), [DATA_RETENTION_AND_PRIVACY.md](DATA_RETENTION_AND_PRIVACY.md) and [FIREBASE_COST_AND_PERFORMANCE.md](FIREBASE_COST_AND_PERFORMANCE.md) define the release gates, controls and cost drivers.

## Missing implementation inputs, without new product decisions

Initial town/stand geometry, target devices/load, support contact and approved hosted text, account/billing ownership, staff identities, operational runbook and final policy periods are UQ08–UQ12/UQ16. Unbooked carpool editing/closure details from [JOURNEY_COVERAGE_REPORT.md](JOURNEY_COVERAGE_REPORT.md) are not expanded into an extra action. The design allows pre-booking cancellation/republish and a derived `full` search condition; any separate edit/close command needs a decision. The legal/privacy gate applies before live evidence or precise-location collection. The Play checkout gate applies separately before Paid activation.
