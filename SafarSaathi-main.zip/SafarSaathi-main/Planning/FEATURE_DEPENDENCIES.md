# Phase 2 — feature dependencies

**Basis:** [feature modules](FEATURE_MODULES.md), [requirements index](REQUIREMENTS_INDEX.md), [decision register](DECISION_REGISTER.md), and the [Q&A](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Questions-and-Answers.md). An arrow means the left module supplies a rule/data contract needed by the right module. This is a design dependency, not a code architecture or scope reduction. The full pilot remains the planning baseline pending client validation.

## Core dependency map

```mermaid
flowchart LR
  M01["M01 Identity and roles"] --> M02["M02 Driver review"]
  M01 --> M03["M03 Service areas"]
  M01 --> M14["M14 Recovery foundation"]
  M02 --> M11["M11 Pass and payment rules"]
  M14 --> M11
  M02 --> M04["M04 Duty and presence"]
  M03 --> M04
  M11 --> M04
  M14 --> M04
  M04 --> M05["M05 E-rickshaw discovery"]
  M03 --> M05
  M05 --> M06["M06 Calls and fare"]
  M06 --> M07["M07 E-rickshaw ride"]
  M04 --> M08["M08 Carpool publication"]
  M03 --> M08
  M08 --> M09["M09 Carpool booking"]
  M11 --> M09
  M09 --> M10["M10 Carpool operation"]
  M06 --> M10
  M07 --> M12["M12 Trips and issues"]
  M09 --> M12
  M10 --> M12
  M02 --> M13["M13 Admin operations"]
  M07 --> M13
  M10 --> M13
  M12 --> M13
```

The diagram omits some transitive edges for legibility. M14 establishes permission, authoritative-state resolution, cached-view and queued-action contracts early, then integrates event-by-event with M04–M13. That later integration does not make every consuming module an initial prerequisite of M14. M08 defines a listing and its post-booking immutability contract; M09 then produces reservations against it. This avoids a circular design order.

## Dependency contracts and critical gates

| Gate | Modules | Contract needed before dependent screens/datasets can be finalized | Trace / unresolved |
| --- | --- | --- | --- |
| Identity and role ownership | M01 → all user modules | Signed-in identity, Passenger/Driver/admin permissions, one account across modes, active-trip role-switch guard. | R01,R22; D01–D03,D23; Q01,Q46,Q55–57 |
| Private evidence to eligibility | M02 → M04,M08,M11,M13 | Person and each vehicle approval, capacity, expiry, correction, suspension scope. | R02–R04,R21; D04–D06,D24–D25; Q02–06,Q78–81; UQ04,UQ10 |
| Towns and locations | M03 → M04,M05,M08,M09 | Separate service enablement and initial pilot town data; origin/destination selection. | R05,R11,R22; D07,D14,D29; Q51–52; UQ08 |
| Shared pass and duty | M11 → M04 → M05,M08,M10 | Free/Paid entitlement, 12-hour shift, GPS/public presence, shared vehicle exclusion, carpool T−30 pause. | R09–R10,R16,R24; D13,D19–D20,D27; Q22–23,Q74–86; UQ01–UQ03,UQ05–UQ06,UQ15 |
| E-rickshaw transaction | M05 → M06 → M07 | Unique selected request and 45-second deadline, accepted-driver busy state, versioned fare/call timing, then booking/PIN/arrival/completion. | R05–R08; D07–D11; Q07–11,Q31,Q37–38 |
| Carpool inventory | M08 → M09 → M10 | Dated listing/capacity/conflict model, atomic seat reservation and 15-minute cutoff, then group PIN/headcount/due. | R11–R16; D14–D21; Q14–26,Q39–40,Q69–73 |
| Direct fare vs pass purchase | M11 ↔ M07,M09,M10 | Ride fare due and receipt are independent of completion; Razorpay verifies only driver access. The double arrow denotes later event integration, not a design-order cycle. | R17,R24; D18,D27–D28; Q18,Q41,Q82–86; UQ05,UQ07,UQ15 |
| Current-state recovery | M14 → each live workflow | Push/deep link resolves server state; offline read, uncertain writes, online PIN, separate queued completion/payment. | R18,R23; D26; Q28–36,Q65–69 |
| History and operations | M07,M09,M10 → M12 → M13 | Owned trip/ticket/issue records feed admin issue queue and immutable booking timeline. Suspension also depends on M02 eligibility. | R19–R21; D22–D25; Q42–49,Q80; UQ07,UQ16 |

## Recommended dataset-and-wireframe sequence

The sequence below is for the **next** phase. “Dataset” means a proposed test-record specification to prepare alongside each screen group; no dataset or wireframe is created in Phase 2.

1. **Identity and shared recovery:** M01 + M14 foundation. Specify account/role/language, permission and current-state examples; wireframe S01–S05,S07–S09, then A01. Use signed-out, applicant, approved, active-trip, denied-permission and reconnect states. This establishes the same navigation and state vocabulary for both modes. Resolve UQ11/UQ12 only where they affect release content or test setup.
2. **Admin-configured eligibility:** M03 + M02 + the Free-pass part of M11 + M04. Specify towns, driver/person/vehicle review, capacity, expiry, shared registration, free entitlement and shift/presence examples together. Wireframe D01–D07,D10,A02–A04,A11–A12. UQ04 and UQ01–UQ03 block affected final approval states; retain explicit variants until answered.
3. **Core e-rickshaw journey:** M05 → M06 → M07, with M14 states on each step and direct-receipt part of M11. Specify two accounts, one eligible driver, a second competing passenger, request/fare versions, GPS loss, arrival/PIN, completion and outstanding receipt. Wireframe P01–P08,D11–D15,S06,S08. This is the first full two-phone journey in the source plan. [Project-plan milestones 1–2](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).
4. **Carpool supply and booking:** M08 → M09. Specify enabled town pair, approved car/e-rickshaw, capacity, overlapping roles/vehicle, last-seat race, multi-seat booking and cutoff cases. Wireframe D16–D18,D22,P09–P14. Keep pass timing as a visible unresolved gate. [Project-plan milestone 3](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).
5. **Carpool operation:** M10 + direct-receipt part of M11 + M14 integration. Specify a three-seat booking with two boarders, a no-show, T−30 on-demand pause, private tracking and offline PIN/receipt outcomes. Wireframe D19–D21,P15 and related S06/S08 states. [Project-plan milestone 3](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).
6. **History, support and admin oversight:** M12 → M13. Specify owned history, private/exported ticket variants, issue states, event timeline, suspension of one vehicle vs whole driver and affected-booking review. Wireframe P16,D23,S10–S11,A05–A10. Resolve UQ07 for policy-specific outcomes before approval. [Project-plan milestone 4](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).
7. **Paid-pass and pilot-readiness variants:** Complete M11 paid paths, then recheck M04/M08/M09/M13 and M14 at mode changes. Specify catalogue, pending/failed/success/duplicate verification, existing-pass transition and pass expiry across both services; wireframe D08–D09 and A12 variants. UQ01–UQ03,UQ05–UQ06,UQ15 must be decided before these workflows can be approved. This ordering does **not** defer paid-pass scope or revise the five-milestone plan; it isolates its unresolved rules for review. [Project-plan pass acceptance](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).

**Review checkpoint:** At the end of each sequence step, check screen IDs against R/D/Q traces, preserve open assumptions in UQ, and validate cross-role state transitions on the same example records. Do not interpret this plan as authorization to build those records or wireframes now.
