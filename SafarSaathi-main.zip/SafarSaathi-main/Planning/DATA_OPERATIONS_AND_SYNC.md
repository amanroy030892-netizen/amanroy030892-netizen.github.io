# Phase 4 — authoritative transactions and offline sync

Every command uses `{uid, actionId, expectedRevision, payload}`. A successful E29 action receipt and the aggregate mutation commit together. The same action ID always returns the original result, including the same booking/pass ID. All boundary times use the server receipt time. Firestore transactions may retry or fail when offline, so external side effects run after commit and interrupted clients query the original receipt ([Firebase transaction semantics](https://firebase.google.com/docs/firestore/manage-data/transactions)).

## Critical boundaries

| Workflow | Authoritative state and preconditions | Atomic commit / failure handling |
| --- | --- | --- |
| Driver eligibility | E03 person approval/licence and single `activeShiftId`, E07 vehicle/RC/capacity, E28 restrictions, E13 pass. For **new on-demand**: E09 active shift, E34 vehicle lock, fresh E10 GPS, no booked carpool within T−30. For **new carpool publication**: current pass; afterward D33 preserves listing through pass expiry. | Re-evaluate in each work-creating function; stale client dashboard cannot grant access. Fail with specific blocker; underway work remains for completion/individual review. |
| Ride request | Named passenger, valid pins/town, eligible selected driver, one active passenger request/ride, driver available. | T writes E16, passenger E02 and duty E09 active-work pointers, and E29; request deadline is server-created +45s. If driver acceptance races expiry, server receipt and transaction winner decide. Rejection clears both pointers and leaves driver available only if current gates still pass. |
| Fare agreement | Accepted request; assigned driver; monotonic offer version; five minutes after acceptance, except active Agora call continues and outstanding offer has 60s after call end. | Offer T increments E17 version. Passenger acceptance T reads latest version/deadline and creates exactly one E18 booking plus event; stale version fails with current offer. Do not let call side effects or FCM alter booking state. |
| Ride pickup/cancel/complete | Assigned booking; arrival before online PIN; either participant may cancel **before** PIN with D50 reason and no fee; five-minute after-arrival no-show is explicit driver action. After PIN, no self-cancel (D46). | T changes E18 and appends E19/E29; PIN verifier rate-limited. Completion sets fare due at drop-off (D45) and clears E02/E09 active-work pointers only after committed completion; direct cash/UPI receipt is a separate idempotent action that may occur later. An interruption after PIN goes to E26 issue and individual admin review, with original events intact. |
| Carpool publication | Approved compatible vehicle, valid docs/capacity, enabled town pair, current pass, non-overlapping account/driver/vehicle commitments. | T reads E03/E07/E08/E13 and per-owner/day E33 ledgers, writes trip E20 with immutable `publicationPassId` snapshot, locks and receipt. Pass expiry later does not hide/cancel the trip (D33). Other suspension/document gates still prevent new work as applicable. |
| Carpool reservation | Published trip, sufficient seats, passenger travels with group, no self-booking/overlap; current listing non-pass gates. | T reads/writes E20 `seatsAvailable`, creates E21/E35 with server PIN and booked fare snapshot, adds E22/E33/E29. Concurrent last-seat race serializes on E20; loser gets `seats_changed`, no booking. No checkout dependency. |
| Passenger seat edit/cancel | Own booking; online server receipt strictly before departure−15m (D16); unchanged ID/PIN; D50 reason on cancellation. | T adjusts E20 counter by `oldSeats−newSeats` and E21, ledgers/events/receipt together. Failed or offline command does **not** release seats. Re-read current inventory/cutoff on retry. |
| Driver trip cancellation | Driver before departure (D47), or staff per specific affected-booking review; D50 reason. | T closes parent E20 and E29. A resumable fan-out cancels E21 children, records E22 and queues notifications. Readers treat parent cancelled as terminal immediately, so partial fan-out cannot expose bookable seats; worker resumes until every child is accounted for. After departure, issue/admin review path only. |
| Boarding and settlement | Direct cash/UPI is paid at carpool pickup (D15). At/after departure, assigned driver verifies group PIN online; `0 ≤ boardedCount ≤ seatsBooked`; booked fare immutable. | T sets E21 boarded/noShow and `dueMinor=boarded×bookedFarePerSeat`, appends E22/E29. Completion and direct receipt are separate T commands; actual due follows recorded headcount. Zero-boarded is no-show, not automatic fare transfer. |
| Pass switch/issuance | E11 mode, E12 one configured paid package, E13 existing entitlements. Free launch; production Paid activation requires D41 written route. | Mode T changes only E11 + audit, never existing E13 (D34). Free grant T snapshots the Q83 12-hour continuous term from issue. Paid order creation is a staged E14 intent followed by external provider creation and a persisted provider ID; retry reconciles the same intent. Verified signed webhook T marks order and creates one E13 at **grant time**. Unique provider event/order/payment constraints prevent duplicate pass. Failed/pending grants none. |
| Deletion | Hosted request accepted; ownership verified; new work restricted; active/upcoming obligations reviewed. | E30 advances through explicit stages. No destructive erase until D38 approved policy and obligations resolved. Each deletion chunk/checkpoint is idempotent; hold only with authorized basis. |

### Schedule overlap serialization

E33 is a **per-owner per-UTC-day ledger document** for each account, driver and vehicle involved in a commitment. A trip spanning days touches every intersected day. Transactions read all relevant ledgers, compare half-open `[start, estimatedArrival)` intervals (adjacent departure at estimated arrival is allowed), then write every touched ledger and trip/booking together. Because Firestore has no predicate locks, a range query alone is insufficient to prevent two concurrent overlap inserts. Ledger size and transaction limits are bounded by a configured maximum planning horizon and maximum commitments per ledger; exceeding either returns a reviewable `schedule_limit` instead of silently skipping a check. Vehicle duty exclusion uses a separate one-document E34 registration lock. Releasing a commitment updates the same ledgers in the cancellation/completion transaction. This is an integrity mechanism, not an approval of a new user-facing limit; deployment values must support the approved pilot scope.

```mermaid
sequenceDiagram
  participant P as Passenger
  participant F as Function
  participant T as Firestore transaction
  P->>F: reserveCarpoolSeats(actionId, tripId, seats)
  F->>T: read receipt, trip, commitments
  T->>T: validate seats and overlap
  T->>T: decrement seats, create booking/locks/event/receipt
  T-->>F: committed booking or conflict
  F-->>P: same result for every retry
```

## Offline recovery

Android keeps a small encrypted local pending-action journal keyed by action ID, target, payload hash and submission state. Firestore offline persistence serves last synced owned booking/ticket/PIN with sync timestamp. The journal is **not** a second authority; it queues only commands the baseline permits offline: driver completion and direct receipt as separate intents. It may retain passenger fare/seat action IDs whose response is uncertain, but never shows them confirmed before server receipt. Driver PIN verification, new seat reservations, seat changes/cancellation, trip cancellation and paid payment/grant require online confirmation. A queued completion rechecks original stage and either commits once or surfaces a conflict; it never overwrites a newer server state. Reconnect runs `getActionResult`, fetches the current aggregate and routes S08/P12/D09 to success, rejection or review. Device clock and local inventory never decide cutoff. FCM deep links contain only target IDs and resolve current state through S07. Cached records and pending intents are removed on sign-out/verified deletion under the approved policy.

```mermaid
stateDiagram-v2
  [*] --> LocalIntent
  LocalIntent --> Submitted: network available
  LocalIntent --> Queued: allowed offline command
  Submitted --> Committed: receipt found
  Submitted --> Unknown: response lost
  Unknown --> Committed: same actionId resolves
  Unknown --> Rejected: authoritative conflict
  Queued --> Submitted: reconnect, same actionId
  Rejected --> Review: user/admin issue if needed
```
