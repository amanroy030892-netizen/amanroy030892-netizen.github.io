# SafarSaathi native Android pilot
Discovery draft • 12 November 2026 • For developer and client review

## Scope and commercial assumptions

Build one Kotlin / Jetpack Compose Android app with Passenger and Driver modes, plus a small admin page on Firebase Hosting. Commercial terms were set aside during development planning. Driver discovery is free at launch. The admin controls free or paid discovery. See the driver discovery packages below. Keep provider bills and Play publication responsibilities explicit.

## Admin-controlled driver passes

SafarSaathi is free to download in both modes. In the admin dashboard, an authorized admin selects Free pass or Paid pass required. Free pass is the initial launch setting. The admin can change the setting in either direction. Record who changed it and when.

In free mode an eligible driver receives the shared discovery pass without payment. In paid mode a driver obtains the shared pass through Razorpay. The same pass covers e-rickshaw discovery and carpool access. ₹100 for 12 consecutive hours is an example package. Breaks and offline time do not pause the clock. Show the current mode and pass expiry on the driver dashboard. Passengers continue paying ride fares directly to drivers by cash or UPI.

Implementation: Cloud Functions enforce the admin setting and verify a successful Razorpay payment before granting a paid pass. Handle repeated payment notifications once. A failed or pending payment grants no paid pass. Keep account login, identity approval, duty status and pass validity separate. An expired pass ends new on-demand work; an underway ride can finish.

Open decisions: confirm treatment of already-issued passes when the mode changes, the final catalogue, and whether carpool eligibility is checked at publication or departure. Before enabling paid checkout in a Play-distributed build, confirm the applicable Play billing route for driver discovery access. [Google Play payments policy](https://support.google.com/googleplay/android-developer/answer/9858738)

Acceptance: Toggle free → paid → free with an authorized admin. A new eligible driver can obtain a free pass without checkout in free mode. In paid mode, verify one successful purchase grants exactly one entitlement, including after a retry. Check the mode change audit record and both service entry points.

## What the supplied prototype establishes

| Reference | Native planning implication |
| --- | --- |
| index.html has a map of on-duty e-rickshaws, grouped stands, driver selection, a call and mutual confirmation of a negotiated fare. It includes a demo control for confirming on the driver's behalf. | Preserve the choice of driver. Each real participant confirms from their own session. |
| The carpool UI searches published routes, offers vacant seats, opens direct-payment actions, asks the driver to acknowledge payment, and displays a shareable ticket. It advertises a 15-minute cancellation cutoff. | The Android flow confirms seats immediately and collects payment directly at pickup. |
| Driver onboarding includes vehicle details, selfie and fee submission. admin.html ties UTR approval to 12 hours of visibility. | Independently model identity approval and on-duty presence. On-demand shifts expire after 12 hours. |
| capacitor.config.json names com.safarsaathi.app. server.js serves static files. The bundle includes a web manifest and service worker. | Reuse approved branding and flow references. Build the Android client and authoritative booking backend from scratch. The native app uses `com.safarsaathi.rides`. |
| The bundle documents administrator and signing credentials. | Replace exposed credentials before deployment. For an existing listing, verify key ownership and the applicable rotation process first. |

Source review was static. Live Firebase configuration, calling, published app status and ownership have not been validated.

## Proposed pilot journeys

### Confirmed registration and driver approval

1. A passenger verifies their mobile number with Firebase OTP and enters their name to book. They can apply to drive using the same account and continue booking while their application is under review.
2. Maintain one driver profile and approve each vehicle separately. An approved driver with an approved e-rickshaw can go on duty for on-demand rides and publish scheduled carpools using that vehicle. An approved car can be used for scheduled carpools.
3. Require a profile photo, both sides of the driving licence, an RC for each vehicle and an Aadhaar document for manual admin review. Plan on a masked Aadhaar upload. QR scanning and OTP-based Aadhaar verification have not been requested.
4. A vehicle registered to a family member, fleet or other owner is eligible for review. Show the registered owner’s name to the admin and request owner authorization when it differs from the applicant’s name.
5. Admins can mark a specific document **Needs correction**, give a reason and notify the applicant. The applicant resubmits that document. Passenger access continues.
6. Updating a profile photo leaves driving access active. A replacement licence goes back for review. Adding a vehicle requires separate RC approval. Other approved vehicles remain usable while the approved licence is valid.

### Confirmed e-rickshaw decisions

1. Open on the nearby-driver map. Default pickup to the passenger’s location, allow moving the pin, and request a destination when requesting a ride.
2. The passenger selects one driver and sees vehicle details. A decline or expiry lets the passenger choose another driver.
3. Accepting the request opens Agora calling for either participant and pauses other requests to that driver. This acceptance begins fare discussion.
4. The driver can submit or revise the fare during the call. The passenger can accept the current amount while still on the call. Both screens retain audio through confirmation. Each acceptance refers to a specific offer version so an unseen revision cannot be booked.
5. After fare confirmation, the driver marks arrival and enters the passenger’s four-digit pickup PIN to start. The driver marks the ride complete at drop-off.
6. Available drivers show approximate public markers. After booking, only the assigned passenger sees the driver's precise live location. Break stops location sharing.
7. Either participant can cancel before pickup. A short expiry releases abandoned fare discussions. Reopen availability only if the driver is still on duty and available. See the confirmed timeout rules below.

Acceptance check: Use two phones on an active Agora call. Submit a fare, revise it, and accept the displayed revision. Verify audio continuity, identical booked amounts, rejection of stale acceptance, and that the pickup PIN starts only the assigned ride.

### Confirmed carpool decisions

1. Only registered, admin-approved drivers may publish trips, using an approved car or e-rickshaw. Driver and vehicle document requirements are recorded above.
2. Each listing is a one-way departure on a specific date. The publisher enters origin town, destination town, pickup and drop-off points, departure date and time, available seats and fare per seat.
3. Passengers search by town pair, date and seat count. Show trips with enough available seats, earliest departure first.
4. A passenger can reserve multiple seats in one booking. Show the total before confirmation. Confirm instantly and deduct all requested seats together. If fewer seats remain, ask the passenger to choose again.
5. The passenger pays the driver directly at pickup by cash or UPI. Seat confirmation happens when the reservation succeeds.
6. Display fare and pickup details before booking. Enable Agora calling between the booking passenger and the driver after confirmation.
7. Passengers may cancel up to 15 minutes before scheduled departure. Return the full booked seat count once. If the driver cancels the trip, notify every booked passenger and mark their bookings cancelled.
8. Issue one four-digit boarding PIN per booking. The driver sees a passenger list with booked seat counts and enters the PIN at pickup to board the group.

### Confirmed rules for drivers offering both services

1. Drivers can publish carpools and receive seat bookings while off duty or on break. On Duty controls e-rickshaw map visibility. Published trips remain searchable until full, closed, cancelled or departed.
2. If at least one carpool seat is booked, pause new on-demand requests starting 30 minutes before departure and explain the pause to the driver. Let an ongoing ride finish and prompt the driver to update waiting passengers if delayed.
3. Collect estimated arrival time at publication. Use departure and estimated arrival to block overlapping carpools for either the same driver or the same vehicle.
4. A boarding PIN identifies the booking. The driver records the actual number boarding, including partial groups. The 15-minute cancellation cutoff still applies.
5. When the driver taps **On the way to pickup**, share carpool location with confirmed passengers and show when it last updated. End sharing at trip completion or cancellation.

### Confirmed live map, connectivity and timeout rules

1. Search for available e-rickshaws within 3 km of the selected pickup pin. If none appear, offer expansion to 5 km. Moving the pin refreshes the search around the new pickup.
2. Passengers can place the pin manually and book without granting location permission. Drivers need location access and GPS to go on duty. If GPS drops during a ride, preserve the booking and tell both participants that tracking is paused.
3. Continue location updates while on duty or sharing an active trip, including with the screen locked or another app open. Show an ongoing Android notification. Break removes the public marker. Private tracking remains available to confirmed carpool passengers once the driver selects **On the way to pickup**.
4. Hide an available driver from the public map after 60 seconds without a fresh location. On a booked ride, display the last known position and the time since the update. Resume with a fresh position on reconnect.
5. A selected driver has 45 seconds to accept an on-demand request. Allow 5 minutes after acceptance for fare discussion. If an Agora call is still active at that deadline, let it continue. When that call ends, allow 60 seconds to accept an outstanding fare. Accepting during the call confirms the booking immediately.

Acceptance check: On two phones, move a manual pickup pin, expand an empty search, lock the driver's screen, interrupt GPS and then internet, and restore both. Verify marker expiry, booking persistence and a fresh position on reconnect. Exercise request expiry, fare expiry and an active call across the five-minute deadline.

### Confirmed ride alerts, calls and booking recovery

1. Show the selected driver the pickup, destination, remaining request time and Accept and Decline actions. When minimized or locked, alert the driver and open the request on tap. Show expired status if the deadline has passed.
2. Incoming Agora calls ring with Answer and Decline, including on a locked phone. Identify the caller by first name and the associated ride. Missed or declined calls leave the booking and applicable fare timer intact.
3. Notify the relevant participant of e-rickshaw request acceptance or decline, new or revised fares, booking confirmation, arrival and cancellation. For carpools, notify the driver of seat bookings and cancellations. Notify booked passengers when the driver heads to pickup or cancels the trip.
4. Update an open booking screen directly and suppress duplicate sounds. During a call show the latest fare and the passenger’s acceptance action on the call screen.
5. On reopening, surface the current e-rickshaw booking through an Active ride card and scheduled trips through Upcoming carpools. An old notification opens the current booking state and explains expiry or cancellation when applicable.

Acceptance check: Receive a request and a call on a locked phone, decline the call and verify that the ride state persists. Revise and accept a fare while connected, then reopen a delayed notification and verify that it displays the current booking.

### Confirmed cancellations, no-shows and completion

1. Either participant may cancel a confirmed e-rickshaw before pickup. Offer one-tap cancellation reasons, record who cancelled and notify the other participant. There is no cancellation fee. The passenger can request another ride immediately.
2. When the driver marks arrival, notify the passenger and display a five-minute wait to both. After five minutes the driver may mark a passenger no-show. Reaching the deadline alone leaves the booking open.
3. At or after carpool departure the driver can record each booking as boarded, partially boarded or a no-show. Calculate the amount due from the actual boarded count multiplied by the booked per-seat fare. Two of three passengers boarding at ₹150 per seat owe ₹300.
4. Once a carpool has a booking, preserve its booked fare, route, pickup point and scheduled departure. A Running late update communicates a revised pickup arrival time. A route or schedule change requires cancelling the trip and republishing so passengers can choose the replacement.
5. Show the agreed e-rickshaw fare at drop-off and each carpool group's total at boarding. Let the driver acknowledge direct payment separately from completing the ride. A completed trip can have an outstanding payment.

Acceptance check: Verify that the no-show action unlocks after five minutes and does not cancel the ride automatically. Partially board a three-seat booking and check the two-seat total. Complete the trip with payment outstanding, then acknowledge receipt without changing the completed trip status.

### Confirmed booking history, tickets and support

1. My rides has Upcoming and Past tabs. Passenger mode lists the user's bookings. Driver mode lists trips they operate, with a passenger list inside each carpool trip.
2. After carpool confirmation, show the booking ID, vehicle number, pickup, drop-off, departure time, reserved seats and expected total. Show the boarding PIN on the signed-in passenger's booking screen. After boarding, show actual headcount and amount due.
3. Offer Android sharing, including WhatsApp, and Save PDF. Shared tickets and PDFs include the itinerary, vehicle number, seat count and booking ID. Exclude boarding PINs and personal phone numbers from both outputs.
4. Passengers and drivers can report an issue from a booking, choose a category such as payment, no-show or driver conduct, and optionally add a note. Attach the booking ID automatically. The admin receives the report and sets its status to Open, In review or Resolved. The reporter sees the status and resolution note.

Acceptance check: Reserve three seats and board two. Verify the expected and actual totals in the booking, inspect both share output and saved PDF for private fields, and resolve a booking-linked report from the admin page. Confirm the reporter sees the resolution.

### Confirmed admin dashboard decisions

1. Each authorized staff member signs in individually with the same admin role. Record the staff identity, timestamp and reason for document approvals, suspensions and issue resolutions.
2. The dashboard opens with two queues: driver and vehicle reviews, and open booking issues. Show oldest pending items first. Highlight corrected documents and display the previous reviewer note on resubmissions.
3. A vehicle suspension immediately blocks new bookings and hides listings for that vehicle. A driver suspension applies across all their vehicles. Show affected active and upcoming bookings to the admin for individual review. Allow the admin to contact participants and cancel a specific booking with a recorded reason. Suspension alone does not cancel existing bookings.
4. Search by booking ID to investigate a dispute. Show the event timeline with the accepted fare or booked seat price, arrival time, boarding count and payment acknowledgement as applicable. Keep the original booking events and add the admin’s resolution separately.

Acceptance check: Suspend one vehicle belonging to a driver with two approved vehicles. Verify that the affected listing disappears and cannot receive new bookings, that the second vehicle remains available, and that existing bookings appear for individual review. Suspend the driver and verify the block applies to both vehicles. Resolve a report and verify the reviewer, time and reason can be traced without changing the original ride events.

### Confirmed service area, languages and branding

- Use **SafarSaathi** as the public name on Android and on tickets. The confirmed Android application ID is `com.safarsaathi.rides`.
- Admins configure the town list and enable each town independently for e-rickshaw pickups and carpool routes. No initial towns have been specified.
- For carpool search and publication, users select origin and destination from the searchable list of enabled towns. Drivers place a pickup pin and can add a landmark.
- Both passenger and driver modes support Assamese, English and Hindi at launch, with an in-app language switch. The admin dashboard uses English.

Acceptance check: Enable a town for carpools only and verify it appears in carpool town selection while remaining unavailable for e-rickshaw pickups. Switch between all three Android languages and verify that the selected town, pickup pin and booking remain the same.

### Confirmed home screen and role switching

1. Passenger Home opens on the e-rickshaw map. A visible E-rickshaw / Carpool switch opens carpool search by town, date and seats. Show a Resume ride card above the map when an e-rickshaw ride is active.
2. Put Switch to Driver on Home. Open the dashboard for an approved driver, show Apply to drive for a new applicant, and show review status or requested corrections for a pending applicant.
3. When an idle on-duty driver switches to Passenger, ask “Go on break and switch?” On confirmation, go on break and switch roles. Keep the driver in an underway trip until it ends. Future carpool bookings remain accessible in Driver mode.
4. On first launch, use the phone language when it is Assamese, English or Hindi. Otherwise use English. Show a language selector on the OTP screen before sign-in.

Acceptance check: Switch languages before OTP, then resume an active ride from Passenger Home. Switch an idle on-duty driver to Passenger and verify the public marker disappears. Attempt the same switch during an underway ride and verify the active trip stays on screen.

### Confirmed maps and route guidance

1. Passengers set a destination pin and may add a landmark. Before accepting the request, the selected e-rickshaw driver sees both pickup and destination.
2. Group nearby available e-rickshaw markers with a count. Tapping a group opens a list of driver names and vehicle numbers. The passenger chooses the individual driver to contact.
3. After booking confirmation, Navigate to pickup opens the pickup coordinates in an installed maps app. After pickup PIN verification starts the ride, Navigate to destination opens the destination coordinates. Returning to SafarSaathi restores the active booking.
4. Before booking, display an approximate straight-line distance from the driver to the passenger's selected pickup, for example “About 800 m from pickup.” The navigation app provides road ETA and turn-by-turn guidance in the first release.

Acceptance check: Place different pickup and destination pins, select a driver from a cluster and verify that only that driver receives the request. Verify the navigation target before and after PIN entry and return from the maps app to the same active booking.

### Confirmed development environments and Play release plan

- Use Firebase emulators for local development, a separate Firebase test project for two-phone GPS, calling and notification tests, and a new client-owned Firebase production project for launch. Prototype data migration is outside the current plan.
- The client plans to delete the previous Play listing and create a new app. Use `com.safarsaathi.rides` for the release build, production Firebase Android registration and new Play listing.
- These are setup decisions. Firebase provisioning and Play Console actions are pending.

### Confirmed offline booking behavior

1. The signed-in passenger can open their last synced active ride or upcoming ticket offline, including pickup details, vehicle number and boarding PIN. Show the last sync time.
2. If connectivity drops after Book seats or Accept fare, show Checking booking status. On reconnect, resolve the original action against the server. Open the booking if it succeeded. Otherwise show current seat availability or the current fare and let the passenger decide whether to retry.
3. The passenger may present the cached PIN offline. The driver needs connectivity to verify it before starting an e-rickshaw ride or boarding a carpool group. Keep the booking open and offer Retry verification if the driver loses signal.
4. The driver can record completion and payment receipt separately offline. Persist each action locally as Pending sync and retry on reconnect. Surface a conflict for review if an intervening admin change conflicts with the action.
5. Carpool cancellation requires connectivity. Seats remain reserved until the server confirms cancellation. Evaluate the 15-minute cutoff against server receipt time.

Acceptance check: Drop the connection after submitting a seat booking but before receiving its acknowledgement. On reconnect, recover the original outcome with no duplicate reservation. Verify that a cached passenger PIN works with an online driver, and that pending completion and payment survive an app restart. Attempt cancellation across the cutoff and confirm inventory follows the server result.

### Confirmed passenger booking limits

1. A passenger may have one active e-rickshaw request or ride at a time. A decline, expiry or cancellation releases the request; completion releases an active ride.
2. The booking passenger travels with their carpool group, holds the boarding PIN and serves as the driver’s contact for all seats.
3. Allow online seat-count edits to the existing booking until the 15-minute cutoff. Show the revised total before confirmation. Confirm an increase only if all extra seats remain available; release removed seats upon confirmation of a decrease. Preserve the booking ID and PIN.
4. Block a passenger from booking overlapping carpools using departure and estimated arrival times. Prevent a driver from booking their own published trip. Permit a return departure at or after the first trip’s estimated arrival.

Acceptance check: Submit two simultaneous e-rickshaw requests from one passenger; only one may remain active. Race a seat increase against another booking for the last seat and verify that inventory stays consistent. Check that an adjacent return trip is accepted and an overlapping trip is blocked.

### Confirmed driver shifts and availability

1. Going On Duty selects one approved e-rickshaw. Automatically select the sole approved e-rickshaw; otherwise let the driver choose. To change vehicles, resolve any current request or ride, go on break and select the next vehicle.
2. End on-demand availability after twelve hours. With Free pass selected, a driver can start a fresh shift manually. With Paid pass required, restarting a shift cannot extend paid access. Let an underway ride finish. Future carpool listings continue under their existing booking rules.
3. Restore public availability after completion has synced, provided GPS is fresh and the driver is still eligible and on duty. Offer Finish and take a break so the driver can complete a ride without becoming available again.
4. Check the account’s carpool schedule across passenger and driver roles when publishing or reserving. Block overlapping commitments in either order using departure and estimated arrival times.

Acceptance check: Expire a shift mid-ride and verify that the driver can complete it without returning to the public map. Verify Finish and take a break has the same map outcome during a valid shift. Try publishing a carpool that overlaps an existing passenger booking, then test the reverse order.

### Confirmed vehicle capacity, shared vehicles and document renewal

1. At vehicle approval, the admin records passenger capacity excluding the driver. Published seat counts for cars and e-rickshaws cannot exceed this capacity.
2. Multiple approved drivers may share a family or fleet vehicle. Approve each driver for that vehicle individually. Identify the shared vehicle by registration number and prevent simultaneous duty sessions or overlapping carpool listings for it across drivers.
3. Record driving licence and RC expiry dates during review. Notify the driver 30 and 7 days before expiry. An expired licence blocks new work for the driver; an expired RC blocks new work for that vehicle. Allow an underway ride to finish and flag upcoming bookings for individual admin review.
4. Accept early renewal uploads. The current approval remains valid until expiry during review. An approved renewal supplies the new expiry date. If the old document expires before approval, pause new work until the replacement is approved.

Acceptance check: Try to publish more than the approved passenger capacity and try to start two duty sessions against one shared registration. Test expiry with a pending renewal during a ride and verify that the ride can finish, new work is blocked at the correct scope and affected future bookings reach the admin queue.

## Planning status

Core pilot journeys are ready for technical design. Use the confirmed sections above for implementation planning. Remaining design outputs include the Android screen map, authoritative booking state transitions, Firebase records and access rules, and a sequence of end-to-end development and acceptance milestones. Before live onboarding, settle retention and deletion for identity documents and precise location data. Before release, confirm pilot towns, test devices, support contact and account provisioning.

## Firebase responsibilities

| Component | Proposed responsibility |
| --- | --- |
| Firebase Authentication | Phone identity, session and admin authentication. Use UID as the record key. |
| Cloud Firestore | Profiles, driver applications, ride requests, published trips, seat reservations, booking history, booking-linked reports and decision timestamps. |
| Realtime Database | Short-lived duty and location records grouped by service area. Listen only while needed. Hide stale markers even if a device never sends its final update. |
| Cloud Functions | Validate role and membership, accept requests, transition trips, transact seat inventory and cancellation, send notifications. Repeated taps or retries must have one effect. |
| Firebase Cloud Messaging | Notify the other participant. Read the authoritative booking on open or reconnect. |
| Cloud Storage | Store submitted driver and vehicle documents privately. Limit access to the submitting user and authorized reviewer, with a deletion schedule. |
| Firebase Hosting | Operator review page, privacy/support and account-deletion instructions. |
| Google Maps SDK / Agora | Map display and private voice calls. Issue short-lived call tokens server-side to the two participants. |

Proposed map privacy: approximate available-driver locations before booking, precise pickup and assigned-driver tracking only for active participants. Use a visible Android location service during agreed duty periods; end public duty updates on break and handle private carpool tracking according to trip status. Confirm screen-off behavior on the target phones. Keep phone numbers and identity evidence out of public map records.

## Delivery and cost decisions

Suggested sequence: first prove OTP, duty/location and a cross-device request. Then finish the ride lifecycle and operator approval. Add carpool inventory and booking. Reserve time for real-device acceptance and handover. Confirm delivery dates separately after technical design.

Estimate operating spend from monthly OTP sends including retries, concurrent map viewers, driver-hours online, location update frequency, document uploads and call minutes. For example, 20 drivers × 4 hours × 30 days × 120 updates/hour gives 288,000 location updates/month at a 30-second interval, before listener traffic. This is a sizing example, not a billing forecast. Use India-only SMS if applicable, resend limits, scoped listeners, Maps API quotas and billing alerts. Real SMS requires billing, deployed Functions require Blaze, and Google Maps SDK requires billing-enabled setup.

Sources: [Firebase phone auth](https://firebase.google.com/docs/auth/faq-and-troubleshooting), [Cloud Functions](https://firebase.google.com/docs/functions/get-started), [Maps SDK billing](https://developers.google.com/maps/documentation/android-sdk/usage-and-billing).

## Acceptance on separate Android phones

- A passenger signs in, an operator approves a driver, and only an approved on-duty driver appears in the pilot area. Break, disconnect and stale GPS each produce the agreed map result.
- A passenger selects a driver, both confirm the same fare, the driver completes the ride and both see its final status after restarting. A second passenger cannot claim the same busy driver.
- Two passengers attempt the last carpool seat. Exactly one succeeds. Cancelling a three-seat booking before the cutoff restores exactly three seats even if retried. For a three-seat booking, the driver can enter one PIN and record two people boarded.
- Declined, expired and cancelled requests clear from both phones. A delayed push opens the current booking state. Permission denial leaves the user a usable recovery path.
- An unrelated account cannot change another ride, approve itself or read private evidence. Handover includes agreed APK/AAB, source, deployment instructions, client account ownership and signing arrangements.

## Discovery record

The companion file **SafarSaathi-Questions-and-Answers.md** records the questions, accepted answers, later revisions and outstanding decisions. Before the paid rollout, confirm when the shared pass is checked for a carpool and how a mode change affects existing passes.
