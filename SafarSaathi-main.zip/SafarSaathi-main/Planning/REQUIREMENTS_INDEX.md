# SafarSaathi requirements index

**Review baseline:** 12 November 2026. **Status:** compiled from the handoff; no client sign-off is recorded. This index summarizes existing planning decisions and does not approve or change them. Use the numbered Q&A as the detailed source of truth for previously answered questions. See [Decision register](DECISION_REGISTER.md) and [Unresolved questions](UNRESOLVED_QUESTIONS.md).

## Source and evidence register

| Source | Authority and limits |
| --- | --- |
| [Project plan](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md) | Current development planning baseline and acceptance checks. |
| [Questions and answers](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Questions-and-Answers.md) | Q01–Q100; incorporates later corrections and explicitly marks open items. Q references below refer here. |
| [Android pilot plan](../WorkingDocs/SafarSaathi-Handoff/SafarSarthi-Android-Pilot-Plan.md) | Detailed discovery draft; proposed Firebase responsibilities and static review of an earlier HTML prototype. |
| [Client confirmation](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Client-Confirmation.docx) | Editable client review form with proposed answers. Its response and approval fields are blank; it is **not** a signed approval. |
| [Handoff orientation](../WorkingDocs/SafarSaathi-Handoff/00-START-HERE.md) and [handoff README](../WorkingDocs/SafarSaathi-Handoff/README.md) | Source order, open decisions, and notice that the original HTML ZIP is absent from this repository. |
| Repository [README](../README.md) and folder READMEs | Repository organization. No implemented Android app, backend, or admin dashboard is present in the reviewed project files. |

**Status language:** “Accepted baseline” means recorded as confirmed in the Q&A and plans, subject to the unsigned client review. “Proposed” means a technical or product plan that is not independently approved. “Open” means a recorded decision or required input is still missing. The source plan calls many pilot journeys “confirmed”; this index preserves their substance while keeping client approval status explicit.

## Product boundary and delivery scope

- One native Android app in Kotlin and Jetpack Compose with Passenger and Driver modes; public name **SafarSaathi**, application ID `com.safarsaathi.rides`. Android supports Assamese, English, and Hindi. The admin dashboard is English and hosted on Firebase Hosting. [Project plan](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md), Q50, Q53.
- The pilot includes on-demand e-rickshaw booking and scheduled one-way carpools, plus driver/vehicle approval, operations, support, passes, and direct ride payment. See the five milestones in the project plan. The app is free to download; free driver passes are the launch setting. An admin can switch to paid passes, with Razorpay used for paid driver access. Q82–86, Q99.
- The original HTML prototype is a **reference**, not evidence of working native functionality or a verified live backend. Its old application ID, demo driver-side confirmation, and UTR approval flow do not define the new build. The prototype ZIP is absent from this repository. [Pilot plan](../WorkingDocs/SafarSaathi-Handoff/SafarSarthi-Android-Pilot-Plan.md), [handoff README](../WorkingDocs/SafarSaathi-Handoff/README.md).

## Roles and permissions

| Role | Allowed actions and visibility | Guardrails | Source |
| --- | --- | --- | --- |
| Passenger, signed in | Verify phone by OTP, enter name, use e-rickshaw and carpool flows, manage own bookings, view own PIN/ticket, report issues, apply to drive. | One active e-rickshaw request/ride; cannot alter another booking, book own carpool, or make overlapping carpool commitments. Location permission is optional when using a manual pickup pin. | Q01, Q07–21, Q28, Q42–45, Q65–73 |
| Driver applicant | Retains passenger access; submits profile and vehicle evidence, sees review/correction status, resubmits flagged documents. | Cannot perform new driver work until the driver and chosen vehicle are approved and documents remain valid. | Q01–06, Q55, Q80–81 |
| Approved driver | Goes on duty with one approved e-rickshaw, receives and handles requests, proposes fares, verifies pickup PINs, completes rides; publishes and operates carpools using approved car or e-rickshaw; records payment separately. | Pass eligibility, document validity, suspension, vehicle capacity, GPS, shift, booking, and schedule gates apply. A driver can publish/receive carpool bookings while off duty or on break, subject to pass timing still open. | Q02, Q09–26, Q41, Q74–86 |
| Authorized staff/admin | Individual sign-in; reviews evidence, requests correction, approves or suspends drivers/vehicles, configures towns and pass mode, investigates booking-linked issues, records resolutions and specific booking cancellations. | Same admin role for each staff member; log identity, time, and reason. Suspension blocks new work at driver or vehicle scope but does not automatically cancel existing bookings. | Q46–49, Q51, Q78–82 |
| System services | Enforce authoritative booking state, atomic seat changes, pass/payment verification, notifications, presence and access rules. | A participant can read or mutate only their permitted records; repeated actions/payment notices have one effect. Technical allocation is proposed in the plans. | [Project plan](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md), Q17, Q20, Q66, Q86 |

The same account can be both passenger and driver. Login, driver approval, on-duty state, and pass validity are separate conditions. Driver approval is per person and vehicle; shared vehicles require an approval for each driver. Q01–06, Q79, Q82–86.

## Functional requirements and business rules

| ID | Area | Accepted planning baseline | Q&A trace |
| --- | --- | --- | --- |
| R01 | Identity | Phone OTP and name to book; one account may apply to drive and still book while under review. | Q01 |
| R02 | Driver review | Profile photo, licence front/back, RC per vehicle, and Aadhaar evidence for manual review; mismatched registered owner needs authorization. Masked Aadhaar and live selfie are separately flagged for confirmation. | Q02–06, Q91 |
| R03 | Corrections and renewal | Per-document correction with reason and resubmission. Photo update keeps access; licence replacement is reviewed; new RC is separately approved. Expiry notices at 30 and 7 days; expired licence blocks driver work, expired RC blocks that vehicle; underway ride may finish. | Q05–06, Q80–81 |
| R04 | Vehicle control | Admin sets passenger capacity excluding driver. Vehicle registration identifies shared vehicles; no concurrent duty sessions or overlapping carpools for that vehicle. | Q78–79 |
| R05 | E-rickshaw discovery | Passenger Home opens map; pickup defaults to location but pin can move; destination pin/landmark is supplied at request. Search 3 km, offer 5 km expansion if empty. Group nearby markers; passenger chooses one driver. | Q07–08, Q27–28, Q54, Q58–59 |
| R06 | Request and fare | Selected driver has 45 seconds to accept. Acceptance makes that driver busy and enables private Agora call. Driver may revise a versioned fare; passenger accepts the displayed version during the call without dropping audio. | Q09–10, Q31–35 |
| R07 | Fare timeout | Fare discussion lasts 5 minutes after acceptance; an active call may continue past it. On call end, 60 seconds remain to accept an outstanding fare. Stale offer acceptance is rejected. | Q10, Q31 |
| R08 | Ride lifecycle | Driver marks arrival; four-digit pickup PIN starts the assigned ride; driver completes at drop-off. Either side may cancel before pickup without fee. After arrival, driver may mark no-show after 5 minutes; timeout alone does not cancel. | Q11, Q37–38 |
| R09 | Availability and tracking | Approximate marker before booking, precise assigned-driver tracking after booking; public marker disappears on break or after 60 seconds without fresh location. Ride persists through GPS/network loss and shows last update. Locked-screen/foreground service tracking with visible notification is planned. | Q12, Q27–30 |
| R10 | Shift | On Duty uses one approved e-rickshaw. Twelve-hour on-demand shift ends availability; current ride can finish. Free mode permits a fresh manual shift; a shift restart cannot extend paid entitlement. Return to map only after completion sync, current eligibility, fresh GPS, and On Duty. | Q74–76 |
| R11 | Carpool publishing/search | Approved driver publishes a one-way dated departure with town pair, pickup/drop-off, time, estimated arrival, seat count, and fare per seat. Approved car or e-rickshaw allowed. Search by enabled towns/date/seats, enough seats, earliest first. | Q14–16, Q24, Q51–52 |
| R12 | Seat inventory | One passenger may book several seats and travels with the group. Confirmation is immediate and atomic; total appears first. Online seat-count edits until 15 minutes before departure preserve booking ID/PIN and atomically adjust inventory. | Q17, Q20–21, Q70–72 |
| R13 | Carpool schedule | Block overlapping commitments across passenger and driver roles, and across the same driver or vehicle. Adjacent return trip may depart at or after estimated arrival. | Q24, Q73, Q77, Q79 |
| R14 | Carpool operation | Booking passenger and driver may call via Agora after confirmation. One four-digit PIN per booking. Driver records boarded, partial, or no-show count at/after departure; due amount = actual boarded count × booked per-seat fare. | Q19, Q21, Q25, Q39 |
| R15 | Carpool changes | Passenger cancellation and seat edits close 15 minutes before departure, evaluated on server receipt. Driver cancellation notifies and cancels all bookings. After first booking, fare, route, pickup, and departure are fixed; only a running-late pickup ETA update is allowed. | Q20, Q40, Q69, Q72 |
| R16 | Dual-service interaction | Off-duty/break does not hide a published carpool. When a booked carpool is 30 minutes from departure, pause new on-demand requests; underway ride finishes. Driver starts private carpool tracking with On the way to pickup; sharing ends on completion/cancellation. | Q22–26, Q29 |
| R17 | Direct payment | Passengers pay ride fare to driver by cash or UPI at pickup/ride end as applicable; booking is not contingent on fare collection. Driver payment acknowledgement is separate from completion; outstanding amount may remain after trip completion. | Q18, Q39, Q41, Q84 |
| R18 | Alerts and recovery | Request/call alerts work on locked or minimized phone; push opens authoritative current state. Notify specified fare, ride, seat, cancellation, and pickup events. Avoid duplicate sounds; active ride/upcoming trips are recoverable on Home. | Q32–36 |
| R19 | Tickets/history | My rides has Upcoming/Past for each role. Signed-in passenger sees carpool booking and PIN; shared/WhatsApp/PDF output excludes PIN and phone numbers. | Q42–44 |
| R20 | Issues/admin | Both participants can file booking-linked issue; admin queue, status (Open/In review/Resolved), resolution note, audit identity/time/reason, booking-event timeline and booking-ID lookup. | Q45–49 |
| R21 | Admin suspension | Vehicle suspension blocks that vehicle; driver suspension blocks all vehicles. New bookings/listings stop; existing active/upcoming bookings go to individual review and may be specifically cancelled with a reason. | Q48 |
| R22 | Towns/language | Admin enables towns separately per service. Android Assamese/English/Hindi with pre-OTP selector and phone-language default; admin English. Language change preserves trip state. | Q50–57 |
| R23 | Offline | Last synced active ride/ticket available offline with sync time and cached passenger PIN. Server resolves uncertain seat/fare submission on reconnect. Driver must be online to verify PIN; completion/payment may queue separately and sync later. Carpool cancellation needs connectivity. | Q65–69 |
| R24 | Passes | Free app; admin-controlled Free pass/Paid pass required, launch Free. One continuous driver pass covers both services; example ₹100/12 hours; Razorpay paid purchase verified server-side once. Break/offline do not pause pass. | Q82–86, Q99 |
| R25 | Maps/navigation | Before booking show straight-line distance, not road ETA. Open installed maps app for pickup then destination; return to same active booking. | Q58–61, Q92 |
| R26 | Release setup | Local Firebase emulators, separate test Firebase project, new client-owned production project; new Play listing and package ID. No prototype-data migration in current plan. Provisioning remains pending. | Q62–64 |

## Existing artifacts, MVP and later scope

| Classification | Contents |
| --- | --- |
| Existing artifacts | Static HTML prototype reviewed in the pilot plan, but its ZIP is not in this repository. Current repository holds planning and client-review files plus folder READMEs. No native app, Firebase backend, admin dashboard, deployed service, or live data was verified in this review. |
| Pilot/MVP baseline | All requirements R01–R26 are presented in the project plan as the five-milestone pilot, including offline recovery, support, document renewal, multilingual Android, pass-mode controls, and paid-pass acceptance tests. This is a broad pilot; the documents do **not** define a smaller cut-down MVP. |
| Launch configuration | Free app download and **Free driver pass** setting. Pass access still uses eligibility rules. The exact pilot towns, devices, policy text, support contact, and account setup are pending. |
| Conditional paid operation | Paid pass mode and Razorpay are specified as switchable product behavior, but first live activation depends on a package catalogue, mode-change rule, carpool pass timing, and an applicable Play checkout decision. The documents do not clearly say whether paid mode must ship enabled and tested on day one or may follow the free pilot. |
| Outside current commitment | QR/OTP Aadhaar verification, address autocomplete, in-app turn-by-turn navigation, normal phone-number call fallback, prototype data migration, and reuse of the old Play listing are not committed. They are not automatically a future roadmap. |
| Future scope | No approved post-pilot feature backlog or release dates are recorded. Later paid activation is anticipated, with the exact launch boundary open. |

## Acceptance evidence called for by the plans

The plans require real two-phone tests for fare revision/acceptance while audio stays active; one busy driver; 45-second request and fare expiry; lock-screen calls; stale GPS/offline recovery; last-seat race and idempotent cancellation; partial boarding totals; booking-linked issue resolution; shared-vehicle and document-expiry gates; language and town configuration; and a free → paid → free pass-mode exercise. These are planned acceptance checks, not recorded test results. [Project plan](../WorkingDocs/SafarSaathi-Handoff/SafarSaathi-Project-Plan.md).
