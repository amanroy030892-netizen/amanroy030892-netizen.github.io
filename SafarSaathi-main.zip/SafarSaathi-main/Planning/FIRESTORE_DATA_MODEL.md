# Phase 4 — Cloud Firestore physical model

[Typed schema](DATA_SCHEMA_DEFINITIONS.md) is canonical for fields. Firestore has no joins or foreign-key constraints: Functions validate references and maintain aggregate counters/locks in transactions. Use opaque IDs, no phone number as a key. Default-deny client writes except a narrowly permitted device token/read marker; all high-risk writes use Functions.

| Path | Entity | Direct read scope | Write authority / access pattern |
| --- | --- | --- | --- |
| `accounts/{uid}` | E01 Account | owner; admin if documented review purpose | Auth creates identity; server provisions access |
| `passengers/{uid}` | E02 Passenger profile | owner; admin if documented review purpose | owner name via validated function; server restrictions |
| `drivers/{uid}` | E03 Driver profile | owner; admin if documented review purpose | server review only; applicant supplies drafts |
| `driverApplications/{uid}` | E04 Driver application | owner; admin if documented review purpose | applicant submits; staff reviews through function |
| `evidence/{evidenceId}` | E05 Evidence record | owner; admin if documented review purpose | owner uploads via constrained path; server finalizes; staff reviews |
| `vehicles/{vehicleId}` | E06 Vehicle | owner; admin if documented review purpose | server creates/normalizes; staff suspension |
| `driverVehicles/{driverId_vehicleId}` | E07 Driver vehicle approval | owner; admin if documented review purpose | staff approval and capacity; server expiry |
| `serviceTowns/{townId}` | E08 Service town | public enabled config | staff config function |
| `dutyShifts/{shiftId}` | E09 Duty shift | owner; admin if documented review purpose | driver command through function; server expiry |
| `config/passPolicy` | E11 Pass policy | public enabled config | staff function only |
| `config/paidPackage` | E12 Paid package | public enabled config | staff function only |
| `passEntitlements/{passId}` | E13 Pass entitlement | owner; admin if documented review purpose | server grant/expiry only |
| `paymentOrders/{orderId}` | E14 Payment order | owner; admin if documented review purpose | server + verified provider webhook |
| `paymentEvents/{provider_eventId}` | E15 Payment event | server/admin operational scope only | verified webhook only |
| `rideRequests/{requestId}` | E16 Ride request | owner and scoped participant; admin if operational need | passenger creates; driver responds; server transitions |
| `rideRequests/{requestId}/fareOffers/{version}` | E17 Fare offer | request participants only | assigned driver proposes; passenger accepts through function |
| `rideBookings/{bookingId}` | E18 E-rickshaw booking | owner and scoped participant; admin if operational need | server transitions; driver receipt acknowledgement |
| `rideBookings/{bookingId}/events/{eventId}` | E19 Ride event | booking/trip participant redacted view; admin timeline | server append only |
| `carpoolTrips/{tripId}` | E20 Carpool trip | owner and scoped participant; admin if operational need | driver publishes; server changes inventory/status |
| `carpoolBookings/{bookingId}` | E21 Carpool booking | owner and scoped participant; admin if operational need | server reserves/edits/cancels/boards; driver receipt |
| `carpoolTrips/{tripId}/events/{eventId}` | E22 Carpool event | booking/trip participant redacted view; admin timeline | server append only |
| `callSessions/{callId}` | E23 Call session | owner and scoped participant; admin if operational need | server issues token and closes session |
| `notifications/{uid}/items/{notificationId}` | E24 Notification | owner; admin if documented review purpose | server creates; owner marks read |
| `deviceTokens/{uid}/tokens/{tokenId}` | E25 Device token | admin/server only | owner registers; server sends/cleans |
| `issues/{issueId}` | E26 Support issue | owner and scoped participant; admin if operational need | participant creates; staff resolves |
| `adminAudit/{auditId}` | E27 Admin audit | server/admin operational scope only | server only |
| `restrictions/{restrictionId}` | E28 Restriction | server/admin operational scope only | staff/server only |
| `actionReceipts/{uid}_{actionId}` | E29 Action receipt | owner; admin if documented review purpose | server only |
| `deletionRequests/{requestId}` | E30 Deletion request | owner; admin if documented review purpose | hosted intake; verified server/staff process |
| `config/retentionPolicy` | E31 Retention policy | server/admin operational scope only | client-approved configuration via controlled admin operation |
| `config/support` | E32 Support config | public enabled config | client-controlled publication |
| `commitmentLocks/{ownerKey_dayKey}` | E33 Commitment lock | server/admin operational scope only | server transaction only |
| `vehicleDutyLocks/{registrationKey}` | E34 Vehicle duty lock | server/admin operational scope only | server transaction only |
| `privateBookingSecrets/{bookingType_bookingId}` | E35 Booking PIN secret | server only; passenger PIN through scoped callable | server creates; scoped getBookingPin callable returns to passenger only |
| `staffAccounts/{uid}` | E36 Staff authorization | staff own authorization status; server privileged checks | client-controlled provisioning through privileged server procedure |

## Query and index plan

| Query | Keys/index | Pagination and consistency |
| --- | --- | --- |
| Passenger and driver Upcoming/Past | `rideBookings` passengerId/driverId + status + createdAt; `carpoolBookings` passengerId + status + bookedAt; `carpoolTrips` driverId + status + departureAt | Separate cursor queries by service, merge bounded pages client-side; no unbounded listener. |
| Carpool search | `carpoolTrips` fromTownId, toTownId, service date, status, departureAt; seatsAvailable range requires Firestore inequality/order constraints | Query a bounded departure window ordered by time; paginate through insufficient-seat results until the requested page is filled or window ends, preserving earliest order. Transaction rechecks actual count. |
| Driver departures and manifest | trips driverId + departureAt; bookings tripId + status + bookedAt | Cursor pagination; manifest listener only while open. |
| Admin review queues | applications/driverVehicles/evidence status + submittedAt; issues status + createdAt | Oldest first with bounded cursor pages; queue counts may be derived counters. |
| Affected bookings | driverId or vehicleId + active/upcoming status + time, separately per collection | Paginate and merge; staff decides each booking, suspension never bulk-cancels. |
| Notification inbox | `notifications/{uid}/items` createdAt descending | Cursor page; active target re-read. |
| Booking timeline | `rideBookings/{id}/events` or `carpoolTrips/{id}/events` at ascending | Cursor page; audit is separate. |
| Exact lookup | Direct document ID (A07) | No scan or phone search. |

Initial composite indexes to declare and verify in emulator query tests: `rideBookings(passengerId ASC,status ASC,createdAt DESC)`, `rideBookings(driverId ASC,status ASC,createdAt DESC)`, `carpoolBookings(passengerId ASC,status ASC,bookedAt DESC)`, `carpoolBookings(tripId ASC,status ASC,bookedAt ASC)`, `carpoolTrips(fromTownId ASC,toTownId ASC,serviceDate ASC,status ASC,departureAt ASC)`, `carpoolTrips(driverId ASC,status ASC,departureAt ASC)`, `driverApplications(status ASC,submittedAt ASC)`, `driverVehicles(status ASC,createdAt ASC)`, `issues(status ASC,createdAt ASC)`, and each user's `notifications/items(createdAt DESC)`. Status can require several cursor queries rather than an `in` query with unstable ordering. Add exact affected-booking indexes only after the chosen query shape is fixed in implementation; no unindexed table scan is acceptable.

Exempt unused large maps, evidence metadata and event payloads from indexing; never index precise coordinates or private file paths for public search. `seatsAvailable` is a transactional counter on one trip, not an independently mutable booking field. A client-visible booking summary may copy immutable fare, town names and vehicle type to avoid joins; canonical IDs/amounts remain on source aggregates. Keep copies small and refresh only where a mutable display requires it. Firestore writes to hot trip/lock documents can contend; retry bounded conflicts and return `capacity_changed`. See [operations](DATA_OPERATIONS_AND_SYNC.md).

## Placeholder shapes

```text
carpoolTrips/{tripId}: { driverId:<uid>, vehicleId:<id>, fromTownId:<id>, toTownId:<id>, serviceDate:<Asia/Kolkata date>, departureAt:<server timestamp>, estimatedArrivalAt:<server timestamp>, seatsTotal:<int>, seatsAvailable:<int>, farePerSeatMinor:<int>, publicationPassId:<id>, status:<enum>, revision:<int> }
carpoolBookings/{bookingId}: { tripId:<id>, passengerId:<uid>, seatsBooked:<int>, bookedFarePerSeatMinor:<int>, pinHash:<verifier>, status:<enum>, revision:<int> }
passEntitlements/{passId}: { driverId:<uid>, issueMode:<free|paid>, issuedAt:<server timestamp>, expiresAt:<server timestamp>, termsSnapshot:<immutable map>, status:<enum> }
```
