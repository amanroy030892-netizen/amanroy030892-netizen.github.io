# Phase 3 — navigation architecture

**Status:** recommended route organization for the unchanged 62-screen [inventory](SCREEN_INVENTORY.md). It uses the accepted planning baseline in [REQUIREMENTS_INDEX.md](REQUIREMENTS_INDEX.md) and [DECISION_REGISTER.md](DECISION_REGISTER.md), pending client validation. Navigation patterns are **design recommendations**, not product decisions or wireframes. The exact tab, drawer, sheet, and button presentation remains for later review. See [SCREEN_TRANSITIONS.md](SCREEN_TRANSITIONS.md) for per-ID guards and outcomes.

## Shared route contract

```mermaid
flowchart TD
  Open["Android app open"] --> S01["S01 launch/language"]
  S01 -->|signed out| S02["S02 phone OTP"]
  S02 -->|name missing| S03["S03 name"]
  S03 --> P01["P01 passenger Home"]
  S01 -->|valid passenger session| P01
  S01 -->|valid driver session| D01["D01 driver dashboard"]
  P01 --> S05["S05 role guard"]
  D01 --> S05
  S05 -->|applicant/pending| D05["D05 application status"]
  S05 -->|new applicant| D02["D02 apply"]
  S05 -->|approved| D01
  S05 -->|to passenger after safe break| P01
  Push["Push/deep link"] --> S07["S07 resolve current state"]
  S07 -->|session missing| S02
  S07 -->|eligible and current| Booking["Existing booking/task screen"]
  S07 -->|offline uncertainty| S08["S08 reconcile"]
```

**Authentication gate:** Android S01/S02/S03 precede booking, driver application and private booking detail. A01 precedes every admin route. A signed-in account without a name reaches S03 before passenger booking. Protected deep links retain the intended ID only through sign-in, then recheck current membership/status. An expired/unauthorized link ends on a safe Home (P01/D01/A02) with an explanation. R01,R18,R23; D03,D23,D26; Q01,Q36,Q65–66.

**Access model:** Passenger mode remains accessible to an applicant, pending driver, approved driver, or suspended driver. Driver work requires approved person, approved vehicle, valid documents, pass eligibility at the applicable action, and duty/GPS where on-demand work requires them. Off-duty/break does not hide booked carpool departures. Admin is a separate individual staff session, not an Android mode. R01–R04,R10–R11,R16,R21,R24; D03–D04,D13,D19,D23–D27.

**Presentation recommendation:** Keep P01 and D01 as mode-specific hubs, with service and history destinations visible from each. Use a task surface for S04/S05/S06/S10, P03/P08/P14, D11/D14/D20/D22, and a transient resolver for S07/S08/P12/D09. This classifies inventory IDs without increasing or reducing them; full-screen treatment remains possible when accessibility or OS behavior calls for it. R18,R23; D26.

## A. Passenger Android

| Aspect | Recommended structure and rule |
| --- | --- |
| Initial entry | S01 → S02/S03 as needed → **P01**. Reopening with an active ride emphasizes P07 through P01's Resume ride. A push goes through S07 and the current record. R01,R18; D03,D26. |
| Primary hierarchy | **P01 Home/map** → P02 pickup/destination → P03 grouped drivers → P04 request review → P05 request status → P06 fare → P07 active ride → P08 cancellation when eligible. The visible service switch opens **P09 carpool search** → P10 results → P11 trip/booking review → P12 uncertain result → P13 ticket → P14 edit/cancel or P15 tracking. **P16 My rides** opens P07/P13/S11. R05–R08,R11–R16,R18–R19. |
| Secondary navigation | P01 exposes P16 history, S05 Switch to Driver, S09 language, and S04 permission recovery at point of need. P07/P13/P16 expose S10 report issue and S11 status. P13 invokes external share/PDF; P07/P13 can invoke S06 call where allowed. R18–R20,R22; D22. |
| Role gate | S05 routes new applicants to D02, pending/correction to D05, approved to D01. An idle on-duty driver must confirm break before P01; an underway driver ride stays in D13. Passenger bookings remain owned by the same account. R01,R10; D03,D13; Q55–56. |
| Back behavior | Back from a draft (P02/P04/P09/P11/P14) returns to its source with selections retained where sensible. Back from P05/P06 does not silently cancel an active request. Back from P07/P13 returns to P01/P16 while the booking remains recoverable. A pre-pickup cancel must be explicit at P08. R08,R18; D11,D26. |
| Offline/session recovery | P01/P16 can show last synced owned work; P07/P13 can show cached booking/PIN with sync time. P11 cannot confirm seats offline; P12/S08 resolve an uncertain server result. P14 cancellation stays unconfirmed and seats remain held until server confirmation. R23; D26. |

## B. Driver Android

| Aspect | Recommended structure and rule |
| --- | --- |
| Initial entry | Valid driver-mode session → **D01 dashboard**. New/pending applicant sees D02/D05 routes, with passenger mode available. Approved driver sees duty, pass and upcoming carpool states distinctly. R01–R03,R10,R16,R24; D03–D06,D13,D19,D27. |
| Primary hierarchy | **D01** → D02 application → D03 evidence/D04 vehicle → D05 status/D06 renewal; D01 → D07 pass → D08 paid package/checkout → D09 verification; D01 → D10 vehicle/duty → D11 incoming request → D12 fare → D13 active assignment → D14 PIN → D15 completion/receipt. D01 → D16 departures → D17 publish or D18 trip → D19 manifest → D20 boarding → D21 operation; D22 cancels a trip. **D23 My rides** opens owned operated work, including D15 for a completed ride with an outstanding receipt. R02–R04,R06–R17,R19,R24. |
| Secondary navigation | D01 exposes S05 passenger switch and S09 language. D13/D18/D21 may open S06 call and S10 issue; D23 may open S11 issue status. D13 invokes installed maps at pickup/destination. D06 is reachable from expiry alerts; D07 from eligibility blocks. R18–R20,R25; D22,D25,D30. |
| Duty/role gate | On Duty in D10 needs one approved e-rickshaw, fresh GPS, no shared-vehicle conflict, shift/pass eligibility. Off-duty/break still permits eligible carpool access. At T−30 for a booked carpool, new on-demand requests pause; an underway e-rickshaw ride completes. S05 cannot remove the driver from underway work. R04,R10,R16,R24; D13,D19–D20,D27; UQ01–UQ03. |
| Back behavior | D11 request response and D12 negotiation remain authoritative when UI closes; Back cannot decline/cancel implicitly. D13/D21 return to D01/D18 with an active-work route. D14/D20 dismiss without verification or boarding. D15 can leave a completed trip with outstanding payment. D17 returns with unsent draft only; after a booking, D18 does not expose fixed-field edits. R06–R08,R15,R17,R23; D08–D11,D17–D18,D26. |
| Offline/session recovery | D01/D23 reopen owned active/upcoming work. Driver PIN verification in D14/D20 waits online. D15/D21 can queue completion and receipt separately, each marked Pending sync; S08 reconciles conflicts. No offline carpool cancellation in D22. R23; D26. |

## C. Shared Android surfaces

| Aspect | Recommended structure and rule |
| --- | --- |
| Initial entry and authentication | S01 chooses locale/resumes; S02 OTP; S03 name. S04 is a point-of-need permission task, not a mandatory passenger location gate. S05 mediates role switches. R01,R09,R22; D02–D03,D12. |
| Calls and notification routes | S06 overlays a participant's current request/booking and returns to that current record. S07 resolves every push/deep link against server status; it never executes an action from stale payload. R06–R07,R18; D08–D10,D26. |
| Recovery and settings | S08 handles pending/uncertain actions, S09 changes language while retaining route state, S10 submits a booking-linked issue, S11 shows status. These surfaces are accessible only to the appropriate participant except S09, which is available in either signed-in mode. R20,R22–R23; D22,D26. |
| Modal and confirmation rule | Permission request, switch-to-break, cancellation reason, seat edit/cancel, PIN entry, and issue entry are task surfaces. Dismissal means **no mutation**. An active call can end while fare discussion remains open under the confirmed timer rule. R07–R08,R15,R23; D10–D11,D16,D26. |
| Offline navigation | Cached P07/P13/P15/D13/D18/D21 may be read where last synced data exists, with age shown. A screen requiring server confirmation shows blocked/retry state rather than a false success. R23; D26. |

## D. Web admin dashboard

| Aspect | Recommended structure and rule |
| --- | --- |
| Initial entry and auth | Dashboard URL → **A01 staff sign-in** → **A02 dual queues**. Any direct URL to A03–A12 rechecks staff authorization and redirects to A01 if needed. Exact admin credential/recovery method is unspecified. R20; D23; Q46–47. |
| Primary hierarchy | **A02** has driver/vehicle reviews (A03,A04) and open issues (A05→A06). Booking-ID lookup A07→A08 timeline serves investigation. A09 suspension → A10 affected-booking review handles specific outcomes. A11 towns and A12 pass mode are configuration branches. R20–R22,R24; D23–D25,D27,D29. |
| Secondary navigation | From A06/A10, open A08 booking timeline; from A08, return to issue or affected-booking context. From A03/A04, reach A09 suspension only for an identified driver/vehicle. Show audit context for every consequential action. R20–R21; D23–D25. |
| Back and confirmations | Browser Back restores a read-only context, never repeats a write. Approve/correction, issue resolution, suspension, specific booking cancellation, town change and pass-mode change require explicit submission and server confirmation. A09 suspension alone cannot cancel A10 bookings. R02–R04,R20–R21,R24; D05–D06,D23–D27. |
| Offline/session recovery | Admin mutation requires connectivity; stale/expired sessions re-enter A01. On reconnect, A02/A08/A10 reload current data before another action. Draft text may be retained locally as a UI convenience, but must not be presented as a committed decision. R20–R21,R23; D23–D26. |

## Entry-point and policy gaps

The handoff calls for hosted privacy/support/account-deletion instructions (R26/D31) but defines no Android entry control or numbered screen. UQ11 remains open. A future entry point should be visible from an existing signed-in surface such as S09 and from a pre-sign-in surface if policy requires it; this is a **recommendation for inventory review**, not an added route. Likewise, a standalone passenger profile screen and admin credential-recovery route are not present in the 62-screen inventory. No route here assumes they exist. The [coverage report](JOURNEY_COVERAGE_REPORT.md) lists recommended changes separately.
