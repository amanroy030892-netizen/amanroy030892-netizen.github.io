# Phase 4 — reconciliation and validation report

**Date:** 13 November 2026. This validates a design proposal against the accepted internal planning baseline. The separate client confirmation form remains unsigned. No schema here is a client-approved legal policy or activated backend.

## Phase 3.5 reconciliation — proposed inventory amendments, separate from inventory

The [readiness report](DATA_MODEL_READINESS_REPORT.md) proposed action/state updates. [SCREEN_INVENTORY.md](SCREEN_INVENTORY.md), [SCREEN_TRANSITIONS.md](SCREEN_TRANSITIONS.md), [USER_JOURNEYS.md](USER_JOURNEYS.md), [NAVIGATION_ARCHITECTURE.md](NAVIGATION_ARCHITECTURE.md) and [LIFECYCLE_STATE_MACHINES.md](LIFECYCLE_STATE_MACHINES.md) retain their historical Phase 3 wording; **no existing ID is added, removed or renamed**. The [screen data mapping](SCREEN_DATA_MAPPING.md) incorporates the later confirmed D33–D53 decisions. The following are the recommended edits to those source inventories/lifecycles when separately approved:

| Existing IDs / source section | Required action/state amendment | Decision |
| --- | --- | --- |
| S01,S09; J01,J10; identity/navigation | Pre-OTP privacy; signed-in privacy/help/hosted deletion link and staged request return state. | D43,D52 |
| A01; J11; staff authentication | Individual email/password, client provisioning and email reset link/state. | D42,D53 |
| D03,D05,A03–A04; J03–J04; person review | Masked Aadhaar without live selfie; reasoned rejection and admin reopen of the same application. Keep legal gate. | D36,D38,D44 |
| D01,D07–D10,D16–D18,D21,P10–P11,P13,A12; J05,J07–J09,J13; pass/shift/carpool lifecycles | Pass snapshot at publication; listing remains bookable after pass expiry; honor issued terms through mode change; independent shift/pass clocks; one editable paid package with grant-time start; production Paid gate. | D33–D35,D37,D39–D41 |
| P07–P08,D13–D15; J02,J06; ride lifecycle | Fare due at drop-off, receipt separate; no self-service cancel after PIN; common pre-pickup reason list. | D45,D46,D50 |
| P14,D18,D22,D21; J07–J09; carpool lifecycle | Passenger T−15 unchanged; driver cancel only before departure; after departure issue/review; common reason list. | D47,D50 |
| S10–S11,A05–A08; J10–J11; issue lifecycle | Five categories, Open/In review/Resolved and note-only resolution, immutable original events. | D48,D49 |
| A10; J11–J12; affected booking/deletion | Staff-only audited phone/external call; individual obligation review after verified deletion request. | D51,D52 |

## Coverage checks

| Check | Result / evidence |
| --- | --- |
| Modules | **14/14** M01–M14 have entities and screen/function contracts. M03 E08; M06 E17/E23; M14 E10/E24/E25/E29/E30; other modules mapped in the [catalog](DATA_ENTITY_CATALOG.md). |
| Screens | **62/62** existing IDs have exactly one row in [SCREEN_DATA_MAPPING.md](SCREEN_DATA_MAPPING.md): 11 shared, 16 passenger, 23 driver, 12 admin. No new ID. |
| Journeys | **13/13** J01–J13 have data support; route-to-entity coverage is listed at the end of the screen mapping. |
| D33–D53 | Every decision has a design consequence in the screen amendments above, entity fields, function gates or operations. D38 and D41 remain external gates. |
| State consistency | E04 reject→reopen; E09 and E13 separate clocks; E20 publication pass snapshot; E18 pre/post PIN boundary; E20 driver cancellation before departure; E26 note-only resolution; E30 staged deletion. These supersede conditional older Phase 3 wording. |
| High-risk writes | Review, eligibility, duty, ride/fare, seats, boarding, pass, payment, restriction, issue resolution and deletion are server-authoritative. Firestore T or staged saga boundaries specified in [operations](DATA_OPERATIONS_AND_SYNC.md). |
| Sensitive data | Private Storage, scoped RTDB, P3 classification, default-deny rules, server authorization, audit and no raw GPS history; policy review pending. |
| Offline | Cached owned ticket/PIN and explicit pending journal; no offline confirmed seat/payment/PIN/cancel; same action ID resolves uncertain result. |

The booking PIN display uses private E35 and `getBookingPin`; E18/E21 retain only the server verifier. This prevents a hash-only schema from leaving P07/P13 without a retrievable PIN.

## Controlled decisions and readiness

UQ08 initial town/stand records; UQ09 devices and load; UQ11 final support contact and legal-reviewed hosted content; UQ12 client account/billing ownership; UQ16 first staff/runbook are implementation/operational inputs. UQ13 brand/prototype fidelity and UQ14 schedule/UAT/handover affect Phase 5/release rather than the data schema. D38 final retention periods and legal/privacy review block live sensitive collection. D41 written Play checkout-route determination blocks production Paid mode; Razorpay remains conditional. Q83 fixes the Free pass at 12 continuous hours from issue; D39 makes the one paid package's price/duration admin-editable and starts it at verified server grant. Intentional purchase/reissue while a pass is still active has no approved stacking or extension rule; the checkout UI should not imply one until decided. Unbooked carpool edit/closed behavior remains an inventory clarification and is not implemented by this architecture.

**Phase 5 readiness:** data contracts are ready for interactive wireframe foundation and feature-by-feature example-record design using the fixed IDs, with the above gates visibly marked. Phase 4 stops here: no datasets, wireframes, Firebase resources, security-rule code, application code or deployment are created.
