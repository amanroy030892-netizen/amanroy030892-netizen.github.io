# Phase 4 — entity relationships

References are IDs checked by server functions; Firestore does not cascade or enforce them. E10 is RTDB, E05 points to private Storage objects.

```mermaid
erDiagram
  ACCOUNT ||--|| PASSENGER_PROFILE : owns
  ACCOUNT o|--o| STAFF_AUTHORIZATION : assigned
  ACCOUNT ||--o| DRIVER_PROFILE : applies
  DRIVER_PROFILE ||--|| DRIVER_APPLICATION : has
  DRIVER_APPLICATION ||--o{ EVIDENCE : submits
  DRIVER_PROFILE ||--o{ DRIVER_VEHICLE : approved_for
  VEHICLE ||--o{ DRIVER_VEHICLE : used_by
  DRIVER_PROFILE ||--o{ DUTY_SHIFT : starts
  DUTY_SHIFT }o--|| VEHICLE_DUTY_LOCK : holds
  DRIVER_PROFILE ||--o{ PASS_ENTITLEMENT : receives
  PASS_POLICY ||--o{ PASS_ENTITLEMENT : governs_issue
  PAID_PACKAGE ||--o{ PAYMENT_ORDER : snapshots
  PAYMENT_ORDER ||--o{ PAYMENT_EVENT : receives
  PAYMENT_ORDER o|--o| PASS_ENTITLEMENT : grants
  PASSENGER_PROFILE ||--o{ RIDE_REQUEST : sends
  RIDE_REQUEST ||--o{ FARE_OFFER : negotiates
  RIDE_REQUEST ||--o| RIDE_BOOKING : confirms
  RIDE_BOOKING ||--o{ RIDE_EVENT : records
  RIDE_BOOKING ||--|| BOOKING_PIN_SECRET : grants_to_booker
  DRIVER_PROFILE ||--o{ CARPOOL_TRIP : publishes
  VEHICLE ||--o{ CARPOOL_TRIP : carries
  SERVICE_TOWN ||--o{ CARPOOL_TRIP : endpoint
  CARPOOL_TRIP ||--o{ CARPOOL_BOOKING : reserves
  CARPOOL_BOOKING ||--|| BOOKING_PIN_SECRET : grants_to_booker
  CARPOOL_TRIP ||--o{ CARPOOL_EVENT : records
  PASSENGER_PROFILE ||--o{ CARPOOL_BOOKING : owns
  ACCOUNT ||--o{ SUPPORT_ISSUE : reports
  ACCOUNT ||--o{ DELETION_REQUEST : requests
```

E IDs and all fields live in [catalog](DATA_ENTITY_CATALOG.md) and [schema definitions](DATA_SCHEMA_DEFINITIONS.md). `CommitmentLock` E33 reserves account/driver/vehicle schedule intervals; `VehicleDutyLock` E34 prevents simultaneous duty on shared registration. They are server-owned integrity records, not user-visible bookings. A lock is released only in the same authoritative cancellation/completion transition that removes its commitment. Event subcollections remain append-only; issue resolution adds an E26 update and E27 audit rather than rewriting them.
