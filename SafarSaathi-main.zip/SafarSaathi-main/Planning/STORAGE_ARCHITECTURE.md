# Phase 4 — private Cloud Storage architecture

Storage objects are bytes; E05 [evidence records](DATA_SCHEMA_DEFINITIONS.md) in Firestore own their review state and references. No file URL or object metadata carries Aadhaar digits, phone number, licence number or exact address. D36 requires **masked Aadhaar evidence**, profile photo, licence sides and per-vehicle RC/owner authorization where applicable; it does **not** require a separate live selfie. Any additional selfie collection would need a new decision.

```text
/private/driverEvidence/{uid}/{evidenceId}/{revision}/{opaqueFileId}
/private/vehicleEvidence/{vehicleId}/{driverUid}/{evidenceId}/{revision}/{opaqueFileId}
/private/supportEvidence/{issueId}/{uid}/{opaqueFileId}  # only if attachment is approved for issue workflow
```

Evidence access is limited to owner upload/read and staff with a documented review purpose. Client uploads use a short-lived, server-created upload intent tied to UID, evidence kind, target and revision. Storage rules constrain exact path, Auth UID, size, MIME allowlist and create-only writes; server finalization verifies actual bytes/type, checks malware/unsafe content according to approved operational policy, strips or avoids sensitive EXIF, and creates/updates E05. Never let an upload itself approve a document. Admin review access is authenticated and purpose logged through a brokered function or expiring signed access, with no public download token. Evidence replacement creates a new revision and preserves the currently approved evidence until review or its own expiry (D06/D25). The pointer switch is server controlled.

Deletion: an orphan sweeper compares finalized E05 references with upload intents; expired incomplete uploads and unreferenced replacements are deleted under approved policy. A confirmed account erasure deletes private objects after obligation review and retention/hold evaluation. No exact lifetime is specified here. Support attachments are a conditional storage path because S10 currently approves only category and optional note; enabling attachment input requires an inventory decision. Storage rules, file validation and least-privilege service accounts must all be tested; rules alone cannot inspect document masking or prove authenticity.
