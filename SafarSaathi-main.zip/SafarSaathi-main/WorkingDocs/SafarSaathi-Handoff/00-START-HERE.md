# SafarSaathi — Codex handoff

Start with SafarSaathi-Project-Plan.md for the project baseline. SafarSaathi-Questions-and-Answers.md gives numbered decisions. SafarSarthi-Android-Pilot-Plan.md is the detailed original plan. SafarSaathi-Client-Confirmation.docx is the editable client review copy, pending client sign-off.

## First task

Continue planning and low-fidelity wireframing. Create a screen inventory by role and map screens to the relevant numbered questions. Begin with passenger and driver screens side by side for one e-rickshaw ride: driver selection, request, Agora call, fare revision and acceptance during the call, arrival, pickup PIN, completion and direct payment. Include offline, expiry and cancellation states. Next map carpool publication, seat reservation, boarding, admin document review and pass settings. Capture open decisions before implementing screens or deploying services.

## Preserve the agreed model

Public name SafarSaathi. Android application ID com.safarsaathi.rides. The download is free. Admins can switch between free passes and paid passes for drivers. Razorpay handles paid pass purchases. Both services use the same driver pass. The example offer is ₹100 for 12 consecutive hours. Passengers pay their drivers directly. Keep sign-in, driver approval, on-duty status and pass validity separate.

## Open decisions

- Carpool pass check at publication or departure. Publication was suggested and awaits confirmation.
- Treatment of active passes when the admin changes mode. Honouring existing passes until expiry was suggested and awaits confirmation.
- Final pass catalogue and applicable Play checkout route.
- Retention of identity evidence and precise location, live selfie requirement, launch towns, target test devices, final icon and handover responsibilities.

Use the original client HTML ZIP as a separate design reference if available. This package contains the planning and client-review documents.
